# BusLanka — Find Your Bus in Sri Lanka

BusLanka is a responsive Sri Lankan public-bus information web app with route search, timetable exploration, district browsing, bus-stand directory, passenger submissions, multilingual UI, and a demo admin dashboard.

## Features

- Search by route number, origin, destination, stop, district, bus stand, registration number, road, or operator
- Filter by district, bus type, and operator
- Route details with stops, photos, contacts, and service information
- Timetable explorer with next-bus calculations
- 25-district browser and district detail pages
- Bus-stand directory
- Passenger correction / new-information submissions
- English, Sinhala, and Tamil UI
- Demo admin dashboard for managing routes, timetables, submissions, and stands
- Sri Lanka time display
- Responsive desktop and mobile layout
- GitHub Pages deployment workflow included

## Run locally

Requirements: Node.js 20+

```bash
npm install
npm run dev
```

Then open the local Vite URL shown in the terminal.

## Build

```bash
npm run build
npm run preview
```

## GitHub Pages deployment

1. Create a GitHub repository and upload this project.
2. Make sure the default branch is `main` (or `master`).
3. In GitHub, open **Settings → Pages**.
4. Under **Build and deployment**, choose **GitHub Actions**.
5. Push the project. The included `.github/workflows/deploy.yml` workflow builds and publishes `dist` automatically.

The Vite configuration uses relative asset paths, so the project works when hosted under a GitHub Pages repository URL.

## Important data note

The current app stores admin edits and passenger submissions in the browser's `localStorage`. That means the data is local to the device/browser and is not a shared online database. The admin passkey is also a demo client-side login and is **not suitable for real security**.

For a real public production system, connect the app to a backend such as Firebase/Supabase and replace the demo admin authentication with server-side authentication and database rules.
