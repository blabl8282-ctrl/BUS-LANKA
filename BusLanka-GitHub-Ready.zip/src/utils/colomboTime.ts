import { TimetableEntry, TimeFormat } from '../types/transit';

/**
 * Returns current Date object shifted to Asia/Colombo (UTC+5:30)
 */
export function getColomboDate(): Date {
  const now = new Date();
  const utcMs = now.getTime() + now.getTimezoneOffset() * 60000;
  const colomboOffsetMs = 5.5 * 3600000; // UTC + 5:30
  return new Date(utcMs + colomboOffsetMs);
}

/**
 * Checks if a service operates on a given date based on its operating days
 */
export function isOperatingOnDate(days: string[] | undefined, date: Date): boolean {
  if (!days || days.length === 0 || days.includes('Daily')) return true;

  const dayOfWeek = date.getDay(); // 0 = Sunday, 1 = Monday, ..., 6 = Saturday
  const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;
  const isWeekday = dayOfWeek >= 1 && dayOfWeek <= 5;

  for (const d of days) {
    if (d === 'Daily') return true;
    if (d === 'Mon-Fri' && isWeekday) return true;
    if (d === 'Weekends' && isWeekend) return true;
    if (d === 'Sun-Thu' && dayOfWeek >= 0 && dayOfWeek <= 4) return true;

    // Direct day match
    const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    if (d === dayNames[dayOfWeek]) return true;
  }

  return false;
}

/**
 * Formats time string "HH:MM" into readable 12-hour AM/PM or 24-hour format
 */
export function formatTime(timeStr: string, format: TimeFormat = '12h'): string {
  if (!timeStr) return '';
  const [hStr, mStr] = timeStr.split(':');
  const h = parseInt(hStr, 10);
  const m = parseInt(mStr, 10);
  if (isNaN(h) || isNaN(m)) return timeStr;

  if (format === '24h') {
    const hh = h < 10 ? `0${h}` : `${h}`;
    const mm = m < 10 ? `0${m}` : `${m}`;
    return `${hh}:${mm}`;
  }

  const ampm = h >= 12 ? 'PM' : 'AM';
  const displayHours = h % 12 === 0 ? 12 : h % 12;
  const displayMinutes = m < 10 ? `0${m}` : `${m}`;
  return `${displayHours}:${displayMinutes} ${ampm}`;
}

export function format12Hour(timeStr: string): string {
  return formatTime(timeStr, '12h');
}

export interface NextDepartureCalculation {
  entry: TimetableEntry;
  departureTimeFormatted: string;
  formattedDeparture?: string;
  arrivalTimeFormatted: string;
  departureStopName: string;
  destination: string;
  secondsRemaining: number;
  minutesRemaining: number;
  statusLabel: string;
  isToday: boolean;
  targetDayName: string;
  operatesToday: boolean;
}

/**
 * Calculates the next departure from a timetable based on current Sri Lanka Time
 * Supports intermediate stops with offset minutes and day of week filtering.
 */
export function getNextDeparture(
  timetable: TimetableEntry[],
  options?: {
    stopOffsetMinutes?: number;
    stopName?: string;
    destinationName?: string;
    timeFormat?: TimeFormat;
    targetDate?: Date;
  }
): NextDepartureCalculation | null {
  if (!timetable || timetable.length === 0) return null;

  const colomboNow = getColomboDate();
  const targetDate = options?.targetDate || colomboNow;
  const offset = options?.stopOffsetMinutes || 0;
  const format = options?.timeFormat || '12h';

  const isCurrentDay =
    targetDate.getFullYear() === colomboNow.getFullYear() &&
    targetDate.getMonth() === colomboNow.getMonth() &&
    targetDate.getDate() === colomboNow.getDate();

  const currentSecondsOfDay = isCurrentDay
    ? colomboNow.getHours() * 3600 + colomboNow.getMinutes() * 60 + colomboNow.getSeconds()
    : 0;

  // Filter entries that operate on target date
  const operatingTodayEntries = timetable.filter((t) => isOperatingOnDate(t.days, targetDate));

  // If no buses operate on this specific day
  if (operatingTodayEntries.length === 0) {
    return null;
  }

  // Parse and calculate scheduled departure time at selected stop
  const parsed = operatingTodayEntries
    .map((entry) => {
      const [h, m] = entry.departureTime.split(':').map((v) => parseInt(v, 10));
      const departureSecondsAtOrigin = (h * 60 + m) * 60;
      const departureSecondsAtStop = departureSecondsAtOrigin + offset * 60;

      // Calculate arrival at stop
      const stopDepartureMinutes = Math.floor(departureSecondsAtStop / 60) % 1440;
      const stopDepH = Math.floor(stopDepartureMinutes / 60);
      const stopDepM = stopDepartureMinutes % 60;
      const stopDepFormatted = `${String(stopDepH).padStart(2, '0')}:${String(stopDepM).padStart(2, '0')}`;

      return {
        entry,
        departureSecondsAtStop,
        stopDepFormatted,
      };
    })
    .sort((a, b) => a.departureSecondsAtStop - b.departureSecondsAtStop);

  // Find next one on target day
  const upcomingToday = parsed.find((p) => p.departureSecondsAtStop >= currentSecondsOfDay);

  if (upcomingToday) {
    const diffSec = upcomingToday.departureSecondsAtStop - currentSecondsOfDay;
    const diffMin = Math.floor(diffSec / 60);

    let statusLabel = '';
    if (diffSec < 60) {
      statusLabel = 'Boarding now';
    } else if (diffMin < 60) {
      statusLabel = `In ${diffMin} min${diffMin === 1 ? '' : 's'}`;
    } else {
      const hours = Math.floor(diffMin / 60);
      const mins = diffMin % 60;
      statusLabel = `In ${hours}h ${mins > 0 ? `${mins}m` : ''}`;
    }

    const depFormatted = formatTime(upcomingToday.stopDepFormatted, format);
    return {
      entry: upcomingToday.entry,
      departureTimeFormatted: depFormatted,
      formattedDeparture: depFormatted,
      arrivalTimeFormatted: formatTime(upcomingToday.entry.arrivalTime, format),
      departureStopName: options?.stopName || upcomingToday.entry.origin,
      destination: options?.destinationName || upcomingToday.entry.destination,
      secondsRemaining: diffSec,
      minutesRemaining: diffMin,
      statusLabel,
      isToday: true,
      targetDayName: 'Today',
      operatesToday: true,
    };
  }

  // If no further departures today, check earliest tomorrow
  const tomorrow = new Date(targetDate.getTime() + 24 * 3600000);
  const tomorrowOperating = timetable.filter((t) => isOperatingOnDate(t.days, tomorrow));

  if (tomorrowOperating.length === 0) {
    return null;
  }

  const parsedTomorrow = tomorrowOperating
    .map((entry) => {
      const [h, m] = entry.departureTime.split(':').map((v) => parseInt(v, 10));
      const departureSecondsAtOrigin = (h * 60 + m) * 60;
      const departureSecondsAtStop = departureSecondsAtOrigin + offset * 60;
      const stopDepartureMinutes = Math.floor(departureSecondsAtStop / 60) % 1440;
      const stopDepH = Math.floor(stopDepartureMinutes / 60);
      const stopDepM = stopDepartureMinutes % 60;
      const stopDepFormatted = `${String(stopDepH).padStart(2, '0')}:${String(stopDepM).padStart(2, '0')}`;
      return {
        entry,
        departureSecondsAtStop,
        stopDepFormatted,
      };
    })
    .sort((a, b) => a.departureSecondsAtStop - b.departureSecondsAtStop);

  const firstTomorrow = parsedTomorrow[0];
  const diffTomorrowSec = (86400 - currentSecondsOfDay) + firstTomorrow.departureSecondsAtStop;
  const diffTomorrowMin = Math.floor(diffTomorrowSec / 60);
  const hours = Math.floor(diffTomorrowMin / 60);
  const tomorrowDepFormatted = `${formatTime(firstTomorrow.stopDepFormatted, format)} (Tomorrow)`;

  return {
    entry: firstTomorrow.entry,
    departureTimeFormatted: tomorrowDepFormatted,
    formattedDeparture: tomorrowDepFormatted,
    arrivalTimeFormatted: formatTime(firstTomorrow.entry.arrivalTime, format),
    departureStopName: options?.stopName || firstTomorrow.entry.origin,
    destination: options?.destinationName || firstTomorrow.entry.destination,
    secondsRemaining: diffTomorrowSec,
    minutesRemaining: diffTomorrowMin,
    statusLabel: `Tomorrow (~${hours}h)`,
    isToday: false,
    targetDayName: 'Tomorrow',
    operatesToday: true,
  };
}
