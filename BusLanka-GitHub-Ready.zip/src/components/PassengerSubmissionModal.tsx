import React, { useState, useEffect } from 'react';
import { X, Send, CheckCircle2, AlertCircle, Bus, Camera, HelpCircle } from 'lucide-react';
import { BusRoute, Language, SubmissionType, BusType, OperatorType } from '../types/transit';
import { storageService } from '../services/storageService';
import { TRANSLATIONS } from '../i18n/translations';

interface PassengerSubmissionModalProps {
  isOpen: boolean;
  onClose: () => void;
  prefillBus?: BusRoute | null;
  currentLang: Language;
  onSubmissionSuccess: () => void;
}

export const PassengerSubmissionModal: React.FC<PassengerSubmissionModalProps> = ({
  isOpen,
  onClose,
  prefillBus,
  currentLang,
  onSubmissionSuccess,
}) => {
  const [submissionType, setSubmissionType] = useState<SubmissionType>('timetable_update');
  const [routeNumber, setRouteNumber] = useState('');
  const [startPoint, setStartPoint] = useState('');
  const [destination, setDestination] = useState('');
  const [busType, setBusType] = useState<BusType>('normal');
  const [operator, setOperator] = useState<OperatorType>('sltb');
  const [registrationNumber, setRegistrationNumber] = useState('');
  const [contactNumber, setContactNumber] = useState('');
  const [photoUrl, setPhotoUrl] = useState('');
  const [photoView, setPhotoView] = useState<'front' | 'rear' | 'side' | 'interior'>('front');
  const [suggestedChanges, setSuggestedChanges] = useState('');
  const [submitterName, setSubmitterName] = useState('');
  const [submitterContact, setSubmitterContact] = useState('');

  const [errorMsg, setErrorMsg] = useState('');
  const [isSuccess, setIsSuccess] = useState(false);

  const t = TRANSLATIONS[currentLang];

  useEffect(() => {
    if (prefillBus) {
      setRouteNumber(prefillBus.routeNumber);
      setStartPoint(prefillBus.startPoint);
      setDestination(prefillBus.destination);
      setBusType(prefillBus.busType);
      setOperator(prefillBus.operator);
      setRegistrationNumber(prefillBus.registrationNumber);
      setContactNumber(prefillBus.verifiedContactNumber);
      setSubmissionType('timetable_update');
    } else {
      setRouteNumber('');
      setStartPoint('');
      setDestination('');
      setBusType('normal');
      setOperator('sltb');
      setRegistrationNumber('');
      setContactNumber('');
      setPhotoUrl('');
      setSuggestedChanges('');
    }
    setErrorMsg('');
    setIsSuccess(false);
  }, [prefillBus, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!routeNumber.trim()) {
      setErrorMsg('Please enter a Route Number (e.g. 01, 138, EX1-01).');
      return;
    }
    if (!startPoint.trim() || !destination.trim()) {
      setErrorMsg('Please provide both Start Point and Destination.');
      return;
    }
    if (!suggestedChanges.trim()) {
      setErrorMsg('Please provide details of the update, revised times, or corrections.');
      return;
    }
    if (!submitterName.trim()) {
      setErrorMsg('Please enter your name.');
      return;
    }
    if (!submitterContact.trim()) {
      setErrorMsg('Please enter your phone number or email address for verification.');
      return;
    }

    try {
      storageService.addSubmission({
        type: submissionType,
        routeNumber: routeNumber.trim(),
        startPoint: startPoint.trim(),
        destination: destination.trim(),
        busType,
        operator,
        registrationNumber: registrationNumber.trim() || undefined,
        contactNumber: contactNumber.trim() || undefined,
        photoUrl: photoUrl.trim() || undefined,
        photoView: photoUrl.trim() ? photoView : undefined,
        suggestedChanges: suggestedChanges.trim(),
        submitterName: submitterName.trim(),
        submitterContact: submitterContact.trim(),
      });

      setIsSuccess(true);
      onSubmissionSuccess();
    } catch {
      setErrorMsg('An error occurred while saving your submission. Please try again.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white rounded-2xl max-w-2xl w-full shadow-2xl border border-slate-200 overflow-hidden my-6">
        {/* Header */}
        <div className="bg-blue-900 text-white p-5 flex items-start justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Bus className="w-5 h-5 text-red-400" />
              <h2 className="text-lg font-bold text-white">{t.submitBusTitle}</h2>
            </div>
            <p className="text-xs text-blue-100">{t.submitBusSubtitle}</p>
          </div>
          <button
            onClick={onClose}
            className="text-blue-200 hover:text-white p-1 rounded transition-colors"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Success Screen */}
        {isSuccess ? (
          <div className="p-8 text-center space-y-4">
            <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-slate-900">Submission Received</h3>
            <p className="text-xs text-slate-600 max-w-md mx-auto leading-relaxed">
              {t.submissionSuccess}
            </p>
            <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 text-xs text-slate-700 max-w-sm mx-auto">
              <span>Status: </span>
              <strong className="text-amber-700">Pending Admin Verification</strong>
            </div>
            <button
              onClick={onClose}
              className="px-6 py-2.5 bg-blue-900 hover:bg-blue-800 text-white rounded-lg text-xs font-semibold transition-colors mt-2"
            >
              Done & Return
            </button>
          </div>
        ) : (
          /* Submission Form */
          <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs text-slate-800">
            {errorMsg && (
              <div className="bg-red-50 border border-red-200 p-3 rounded-lg flex items-center gap-2 text-red-700">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            {/* Submission Type */}
            <div>
              <label className="block font-semibold text-slate-700 mb-1.5">
                {t.typeOfSubmission} *
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {[
                  { id: 'timetable_update', label: 'Timetable Change' },
                  { id: 'route_correction', label: 'Route Correction' },
                  { id: 'new_bus', label: 'New Bus Route' },
                  { id: 'photo_upload', label: 'Bus Photo' },
                ].map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setSubmissionType(item.id as SubmissionType)}
                    className={`py-2 px-2 text-center rounded-lg border text-xs font-medium transition-colors ${
                      submissionType === item.id
                        ? 'bg-blue-900 text-white border-blue-900'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Route & Endpoints */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Route Number *
                </label>
                <input
                  type="text"
                  value={routeNumber}
                  onChange={(e) => setRouteNumber(e.target.value)}
                  placeholder="e.g. 01, 138, EX1-01"
                  className="w-full bg-white border border-slate-300 rounded-lg p-2 font-mono text-slate-900 focus:outline-none focus:ring-1 focus:ring-blue-600"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Start Point *
                </label>
                <input
                  type="text"
                  value={startPoint}
                  onChange={(e) => setStartPoint(e.target.value)}
                  placeholder="e.g. Pettah Fort"
                  className="w-full bg-white border border-slate-300 rounded-lg p-2 text-slate-900 focus:outline-none focus:ring-1 focus:ring-blue-600"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Destination *
                </label>
                <input
                  type="text"
                  value={destination}
                  onChange={(e) => setDestination(e.target.value)}
                  placeholder="e.g. Kandy Goodshed"
                  className="w-full bg-white border border-slate-300 rounded-lg p-2 text-slate-900 focus:outline-none focus:ring-1 focus:ring-blue-600"
                  required
                />
              </div>
            </div>

            {/* Operator and Service Type */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Bus Service Type
                </label>
                <select
                  value={busType}
                  onChange={(e) => setBusType(e.target.value as BusType)}
                  className="w-full bg-white border border-slate-300 rounded-lg p-2 text-slate-900 focus:outline-none focus:ring-1 focus:ring-blue-600"
                >
                  <option value="normal">Normal Service (Standard Bus)</option>
                  <option value="semi_luxury">Semi-Luxury</option>
                  <option value="luxury_ac">Luxury / AC Coach</option>
                  <option value="expressway">Expressway Highway Service</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Bus Operator
                </label>
                <select
                  value={operator}
                  onChange={(e) => setOperator(e.target.value as OperatorType)}
                  className="w-full bg-white border border-slate-300 rounded-lg p-2 text-slate-900 focus:outline-none focus:ring-1 focus:ring-blue-600"
                >
                  <option value="sltb">Sri Lanka Transport Board (SLTB)</option>
                  <option value="private">Private Bus Operator (NTC / Provincial)</option>
                </select>
              </div>
            </div>

            {/* Reg No and Contact */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Bus Registration Number (Optional)
                </label>
                <input
                  type="text"
                  value={registrationNumber}
                  onChange={(e) => setRegistrationNumber(e.target.value)}
                  placeholder="e.g. NB-4521, WP ND-8920"
                  className="w-full bg-white border border-slate-300 rounded-lg p-2 font-mono text-slate-900 focus:outline-none focus:ring-1 focus:ring-blue-600"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Depot / Hotline Phone (Optional)
                </label>
                <input
                  type="text"
                  value={contactNumber}
                  onChange={(e) => setContactNumber(e.target.value)}
                  placeholder="e.g. +94 11 258 1120"
                  className="w-full bg-white border border-slate-300 rounded-lg p-2 text-slate-900 focus:outline-none focus:ring-1 focus:ring-blue-600"
                />
              </div>
            </div>

            {/* Photo Contribution */}
            {submissionType === 'photo_upload' && (
              <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 space-y-2">
                <div className="flex items-center gap-1.5 text-blue-900 font-semibold">
                  <Camera className="w-4 h-4" />
                  <span>Bus Photo Contribution</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  <div className="sm:col-span-2">
                    <label className="block text-[11px] font-medium text-slate-600 mb-0.5">
                      Photo Image URL / Hosted link
                    </label>
                    <input
                      type="url"
                      value={photoUrl}
                      onChange={(e) => setPhotoUrl(e.target.value)}
                      placeholder="https://... or image link"
                      className="w-full bg-white border border-slate-300 rounded p-1.5 text-xs text-slate-900"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-medium text-slate-600 mb-0.5">
                      Photo View
                    </label>
                    <select
                      value={photoView}
                      onChange={(e) => setPhotoView(e.target.value as any)}
                      className="w-full bg-white border border-slate-300 rounded p-1.5 text-xs text-slate-900"
                    >
                      <option value="front">Front View</option>
                      <option value="side">Side View</option>
                      <option value="interior">Interior View</option>
                      <option value="rear">Rear View</option>
                    </select>
                  </div>
                </div>
              </div>
            )}

            {/* Changes description */}
            <div>
              <label className="block font-semibold text-slate-700 mb-1">
                {t.suggestedChanges} *
              </label>
              <textarea
                rows={3}
                value={suggestedChanges}
                onChange={(e) => setSuggestedChanges(e.target.value)}
                placeholder="Describe departure time change, missing intermediate halts, or road changes..."
                className="w-full bg-white border border-slate-300 rounded-lg p-2 text-slate-900 focus:outline-none focus:ring-1 focus:ring-blue-600"
                required
              />
            </div>

            {/* Submitter Info */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-slate-100">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  {t.submitterName} *
                </label>
                <input
                  type="text"
                  value={submitterName}
                  onChange={(e) => setSubmitterName(e.target.value)}
                  placeholder="e.g. Kasun Silva"
                  className="w-full bg-white border border-slate-300 rounded-lg p-2 text-slate-900 focus:outline-none focus:ring-1 focus:ring-blue-600"
                  required
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  {t.submitterContact} *
                </label>
                <input
                  type="text"
                  value={submitterContact}
                  onChange={(e) => setSubmitterContact(e.target.value)}
                  placeholder="e.g. +94 77 123 4567 or email"
                  className="w-full bg-white border border-slate-300 rounded-lg p-2 text-slate-900 focus:outline-none focus:ring-1 focus:ring-blue-600"
                  required
                />
              </div>
            </div>

            {/* Submit Buttons */}
            <div className="flex items-center justify-end gap-2 pt-4 border-t border-slate-200">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 border border-slate-300 rounded-lg text-slate-700 hover:bg-slate-100 font-medium transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex items-center gap-1.5 px-5 py-2 bg-blue-900 hover:bg-blue-800 text-white rounded-lg font-semibold transition-colors shadow-xs"
              >
                <Send className="w-3.5 h-3.5" />
                <span>{t.sendSubmission}</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
