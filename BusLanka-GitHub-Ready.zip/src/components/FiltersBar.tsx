import React from 'react';
import { Filter, RotateCcw } from 'lucide-react';
import { Language, DistrictId, BusType, OperatorType } from '../types/transit';
import { SRI_LANKA_PROVINCES, SRI_LANKA_DISTRICTS } from '../data/sriLankaProvinces';
import { TRANSLATIONS } from '../i18n/translations';

interface FiltersBarProps {
  currentLang: Language;
  selectedDistrict: DistrictId | 'all';
  onDistrictChange: (district: DistrictId | 'all') => void;
  selectedBusType: BusType | 'all';
  onBusTypeChange: (type: BusType | 'all') => void;
  selectedOperator: OperatorType | 'all';
  onOperatorChange: (op: OperatorType | 'all') => void;
  onResetFilters: () => void;
  resultsCount: number;
  totalBuses: number;
}

export const FiltersBar: React.FC<FiltersBarProps> = ({
  currentLang,
  selectedDistrict,
  onDistrictChange,
  selectedBusType,
  onBusTypeChange,
  selectedOperator,
  onOperatorChange,
  onResetFilters,
  resultsCount,
  totalBuses,
}) => {
  const t = TRANSLATIONS[currentLang];

  const hasActiveFilters =
    selectedDistrict !== 'all' || selectedBusType !== 'all' || selectedOperator !== 'all';

  return (
    <div className="bg-slate-50 border-b border-slate-200 py-4 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-4">
        {/* Filter controls row */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-700 shrink-0">
            <Filter className="w-3.5 h-3.5 text-slate-500" />
            <span>Filter:</span>
          </div>

          {/* District Selector grouped by Province */}
          <div className="relative">
            <select
              value={selectedDistrict}
              onChange={(e) => onDistrictChange(e.target.value as DistrictId | 'all')}
              className="text-xs bg-white border border-slate-300 rounded-lg py-2 px-3 text-slate-800 font-medium focus:outline-none focus:ring-1 focus:ring-blue-600 focus:border-blue-600 shadow-2xs"
            >
              <option value="all">{t.allDistricts}</option>
              {SRI_LANKA_PROVINCES.map((prov) => {
                const provName =
                  currentLang === 'si'
                    ? prov.nameSi
                    : currentLang === 'ta'
                    ? prov.nameTa
                    : prov.nameEn;
                const dists = SRI_LANKA_DISTRICTS.filter((d) => prov.districts.includes(d.id));
                return (
                  <optgroup key={prov.id} label={`── ${provName} ──`}>
                    {dists.map((d) => {
                      const dName =
                        currentLang === 'si'
                          ? d.nameSi
                          : currentLang === 'ta'
                          ? d.nameTa
                          : d.nameEn;
                      return (
                        <option key={d.id} value={d.id}>
                          {dName}
                        </option>
                      );
                    })}
                  </optgroup>
                );
              })}
            </select>
          </div>

          {/* Bus Service Type Filter */}
          <select
            value={selectedBusType}
            onChange={(e) => onBusTypeChange(e.target.value as BusType | 'all')}
            className="text-xs bg-white border border-slate-300 rounded-lg py-2 px-3 text-slate-800 font-medium focus:outline-none focus:ring-1 focus:ring-blue-600 focus:border-blue-600 shadow-2xs"
          >
            <option value="all">{t.allTypes}</option>
            <option value="normal">{t.normal}</option>
            <option value="semi_luxury">{t.semiLuxury}</option>
            <option value="luxury_ac">{t.luxuryAc}</option>
            <option value="expressway">{t.expressway}</option>
          </select>

          {/* Operator Filter */}
          <select
            value={selectedOperator}
            onChange={(e) => onOperatorChange(e.target.value as OperatorType | 'all')}
            className="text-xs bg-white border border-slate-300 rounded-lg py-2 px-3 text-slate-800 font-medium focus:outline-none focus:ring-1 focus:ring-blue-600 focus:border-blue-600 shadow-2xs"
          >
            <option value="all">{t.allOperators}</option>
            <option value="sltb">{t.sltb}</option>
            <option value="private">{t.privateOp}</option>
          </select>

          {/* Clear Filters */}
          {hasActiveFilters && (
            <button
              onClick={onResetFilters}
              className="flex items-center gap-1 text-xs text-red-600 hover:text-red-700 font-medium px-2 py-1.5 rounded hover:bg-red-50 transition-colors"
            >
              <RotateCcw className="w-3 h-3" />
              <span>{t.clearFilters}</span>
            </button>
          )}
        </div>

        {/* Counter of results with tabular numerals */}
        <div className="text-xs text-slate-500 font-medium flex items-center gap-2">
          <span>Showing</span>
          <span className="font-mono tabular-nums text-slate-900 font-bold bg-white px-2 py-0.5 rounded border border-slate-200">
            {resultsCount} of {totalBuses}
          </span>
          <span>{t.busesFound}</span>
        </div>
      </div>
    </div>
  );
};
