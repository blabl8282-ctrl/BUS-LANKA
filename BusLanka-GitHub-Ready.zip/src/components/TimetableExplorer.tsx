import React, { useState, useEffect, useMemo } from 'react';
import {
  Clock,
  Calendar,
  MapPin,
  ArrowRight,
  Filter,
  RotateCcw,
  Bus,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  ChevronDown,
  Timer,
  Sun,
  Moon,
  Sunset,
  Search,
  Sparkles,
  Info,
  PlusCircle,
  Check,
} from 'lucide-react';
import { BusRoute, Language, TimeFormat, TimetableEntry, RouteStop } from '../types/transit';
import {
  getColomboDate,
  formatTime,
  getNextDeparture,
  isOperatingOnDate,
  NextDepartureCalculation,
} from '../utils/colomboTime';
import { TRANSLATIONS } from '../i18n/translations';

interface TimetableExplorerProps {
  buses: BusRoute[];
  currentLang: Language;
  onSelectBus: (bus: BusRoute) => void;
  onOpenSubmitModal?: (bus: BusRoute) => void;
  preselectedRouteId?: string;
}

export const TimetableExplorer: React.FC<TimetableExplorerProps> = ({
  buses,
  currentLang,
  onSelectBus,
  onOpenSubmitModal,
  preselectedRouteId,
}) => {
  const t = TRANSLATIONS[currentLang];

  // Search keyword (searches route number, start, destination, stops)
  const [routeSearchKeyword, setRouteSearchKeyword] = useState<string>('');

  // Selected Route ID
  const [selectedRouteId, setSelectedRouteId] = useState<string>(
    preselectedRouteId || buses[0]?.id || ''
  );

  // When preselectedRouteId changes from parent, sync state
  useEffect(() => {
    if (preselectedRouteId) {
      setSelectedRouteId(preselectedRouteId);
    }
  }, [preselectedRouteId]);

  // Origin & Destination dropdown filters for route discovery
  const [filterOrigin, setFilterOrigin] = useState<string>('all');
  const [filterDestination, setFilterDestination] = useState<string>('all');

  // Direction: 'forward' (Outbound) or 'return' (Inbound)
  const [direction, setDirection] = useState<'forward' | 'return'>('forward');

  // Boarding Stop filter (defaults to 'origin')
  const [selectedBoardingStop, setSelectedBoardingStop] = useState<string>('origin');

  // Time format toggle: 12h vs 24h
  const [timeFormat, setTimeFormat] = useState<TimeFormat>('12h');

  // Date selection: 'today' | 'tomorrow' | 'custom'
  const [dateMode, setDateMode] = useState<'today' | 'tomorrow' | 'custom'>('today');
  const [customDateStr, setCustomDateStr] = useState<string>(() => {
    const d = getColomboDate();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  });

  // Time range filter: 'all' | 'morning' | 'afternoon' | 'evening' | 'night'
  const [timeRange, setTimeRange] = useState<'all' | 'morning' | 'afternoon' | 'evening' | 'night'>('all');

  // Live timer tick for real-time second-by-second countdown
  const [tick, setTick] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setTick((prev) => prev + 1);
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Filtered bus options for selector based on search & origin/destination filters
  const filteredRouteOptions = useMemo(() => {
    return buses.filter((b) => {
      if (filterOrigin !== 'all' && b.startPoint !== filterOrigin && b.destination !== filterOrigin) {
        return false;
      }
      if (filterDestination !== 'all' && b.destination !== filterDestination && b.startPoint !== filterDestination) {
        return false;
      }
      if (routeSearchKeyword.trim()) {
        const q = routeSearchKeyword.toLowerCase().trim();
        const matchRoute = b.routeNumber.toLowerCase().includes(q);
        const matchName = b.nameEn.toLowerCase().includes(q) || b.nameSi.toLowerCase().includes(q) || b.nameTa.toLowerCase().includes(q);
        const matchStart = b.startPoint.toLowerCase().includes(q);
        const matchDest = b.destination.toLowerCase().includes(q);
        const matchStops = b.intermediateStops.some((s) => s.toLowerCase().includes(q));
        const matchReg = b.registrationNumber.toLowerCase().includes(q);
        const matchOperator = b.operatorName.toLowerCase().includes(q);
        if (!matchRoute && !matchName && !matchStart && !matchDest && !matchStops && !matchReg && !matchOperator) {
          return false;
        }
      }
      return true;
    });
  }, [buses, routeSearchKeyword, filterOrigin, filterDestination]);

  // Unique origins and destinations for dropdowns
  const uniqueOrigins = useMemo(() => {
    const set = new Set<string>();
    buses.forEach((b) => {
      set.add(b.startPoint);
    });
    return Array.from(set).sort();
  }, [buses]);

  const uniqueDestinations = useMemo(() => {
    const set = new Set<string>();
    buses.forEach((b) => {
      set.add(b.destination);
    });
    return Array.from(set).sort();
  }, [buses]);

  // Currently active selected bus
  const activeBus = useMemo(() => {
    const found = buses.find((b) => b.id === selectedRouteId);
    if (found) return found;
    return filteredRouteOptions[0] || buses[0];
  }, [buses, selectedRouteId, filteredRouteOptions]);

  // When active bus changes, reset boarding stop if it doesn't belong
  useEffect(() => {
    setSelectedBoardingStop('origin');
  }, [activeBus?.id, direction]);

  // Selected date object shifted to Asia/Colombo (UTC+5:30)
  const targetDate = useMemo(() => {
    const colombo = getColomboDate();
    if (dateMode === 'today') return colombo;
    if (dateMode === 'tomorrow') {
      return new Date(colombo.getTime() + 24 * 3600000);
    }
    const [y, m, d] = customDateStr.split('-').map((n) => parseInt(n, 10));
    return new Date(y, m - 1, d, colombo.getHours(), colombo.getMinutes(), colombo.getSeconds());
  }, [dateMode, customDateStr, tick]);

  const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const targetDayOfWeekName = dayNames[targetDate.getDay()];

  // Stops list for the active direction
  const routeStops = useMemo(() => {
    if (!activeBus) return [];
    if (direction === 'forward') {
      return activeBus.orderedStops && activeBus.orderedStops.length > 0
        ? activeBus.orderedStops
        : activeBus.intermediateStops.map((name, i): RouteStop => ({
            order: i + 1,
            nameEn: name,
            estimatedMinutesFromStart: i * 20,
          }));
    } else {
      // Reversed list for return direction
      const base = activeBus.orderedStops && activeBus.orderedStops.length > 0
        ? [...activeBus.orderedStops].reverse()
        : [...activeBus.intermediateStops].reverse().map((name, i): RouteStop => ({
            order: i + 1,
            nameEn: name,
            estimatedMinutesFromStart: i * 20,
          }));
      return base.map((s, idx) => ({
        ...s,
        order: idx + 1,
        estimatedMinutesFromStart: idx * 20,
      }));
    }
  }, [activeBus, direction]);

  // Intermediate stop offset minutes from starting terminal
  const stopOffsetMinutes = useMemo(() => {
    if (selectedBoardingStop === 'origin') return 0;
    const found = routeStops.find((s) => s.nameEn === selectedBoardingStop);
    return found?.estimatedMinutesFromStart || 0;
  }, [routeStops, selectedBoardingStop]);

  // Raw timetable entries for the active direction
  const rawTimetable = useMemo(() => {
    if (!activeBus) return [];
    return direction === 'forward' ? activeBus.timetableForward || [] : activeBus.timetableReturn || [];
  }, [activeBus, direction]);

  // Does this route have any timetables at all?
  const hasTimetable = rawTimetable.length > 0;

  // Filtered timetable according to date, operating days, and time of day range
  const filteredTimetable = useMemo(() => {
    if (!hasTimetable) return [];
    return rawTimetable.filter((entry) => {
      // 1. Operating days check for target date
      if (!isOperatingOnDate(entry.days, targetDate)) {
        return false;
      }

      // 2. Time range filter
      if (timeRange !== 'all') {
        const hour = parseInt(entry.departureTime.split(':')[0], 10);
        if (timeRange === 'morning' && (hour < 5 || hour >= 12)) return false;
        if (timeRange === 'afternoon' && (hour < 12 || hour >= 17)) return false;
        if (timeRange === 'evening' && (hour < 17 || hour >= 21)) return false;
        if (timeRange === 'night' && (hour >= 5 && hour < 21)) return false;
      }

      return true;
    });
  }, [rawTimetable, targetDate, timeRange, hasTimetable]);

  // Next scheduled bus live calculation
  const nextDepartureCalc = useMemo(() => {
    if (!activeBus || rawTimetable.length === 0) return null;
    return getNextDeparture(rawTimetable, {
      stopOffsetMinutes,
      stopName:
        selectedBoardingStop === 'origin'
          ? direction === 'forward'
            ? activeBus.startPoint
            : activeBus.destination
          : selectedBoardingStop,
      destinationName: direction === 'forward' ? activeBus.destination : activeBus.startPoint,
      timeFormat,
      targetDate,
    });
  }, [
    activeBus,
    rawTimetable,
    stopOffsetMinutes,
    selectedBoardingStop,
    direction,
    timeFormat,
    targetDate,
    tick,
  ]);

  const activeFirstBus = direction === 'forward' ? activeBus?.firstBusForward : activeBus?.firstBusReturn;
  const activeLastBus = direction === 'forward' ? activeBus?.lastBusForward : activeBus?.lastBusReturn;

  const currentOriginName = direction === 'forward' ? activeBus?.startPoint : activeBus?.destination;
  const currentDestName = direction === 'forward' ? activeBus?.destination : activeBus?.startPoint;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* 1. Header with Clock Display Switcher */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="bg-red-600 text-white text-xs font-bold px-2 py-0.5 rounded tracking-wide uppercase">
              Official Timetables
            </span>
            <span className="text-xs text-slate-500 font-medium">
              Asia/Colombo Standard Time (UTC+5:30)
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Sri Lankan Bus Timetables & Live Departure Calculator
          </h1>
          <p className="text-slate-600 text-xs sm:text-sm mt-1">
            Look up scheduled departure times, arrival times at intermediate stops, operating days, and real-time next bus countdowns.
          </p>
        </div>

        {/* 12-Hour vs 24-Hour Format Toggle */}
        <div className="flex items-center gap-2 shrink-0 bg-white p-1 rounded-xl border border-slate-200 shadow-2xs">
          <span className="text-xs font-semibold text-slate-600 px-2">Time Format:</span>
          <button
            onClick={() => setTimeFormat('12h')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors ${
              timeFormat === '12h'
                ? 'bg-blue-900 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            12-Hour (AM/PM)
          </button>
          <button
            onClick={() => setTimeFormat('24h')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors ${
              timeFormat === '24h'
                ? 'bg-blue-900 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            24-Hour (24h)
          </button>
        </div>
      </div>

      {/* 2. MULTI-CRITERIA TIMETABLE SEARCH & DISCOVERY BAR */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-4">
        {/* Top search input row */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={routeSearchKeyword}
              onChange={(e) => setRouteSearchKeyword(e.target.value)}
              placeholder="Search route (01, EX1-01), town (Kandy, Galle), stop, or reg no..."
              className="w-full bg-slate-50 border border-slate-300 rounded-lg pl-10 pr-4 py-2 text-xs text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-900 focus:bg-white"
            />
            {routeSearchKeyword && (
              <button
                onClick={() => setRouteSearchKeyword('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-600"
              >
                Clear
              </button>
            )}
          </div>

          {/* Quick origin & destination filter pills */}
          <div className="flex items-center gap-2 shrink-0">
            <select
              value={filterOrigin}
              onChange={(e) => setFilterOrigin(e.target.value)}
              className="bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-2 text-xs text-slate-700 font-medium focus:outline-none focus:ring-2 focus:ring-blue-900"
            >
              <option value="all">Any Origin</option>
              {uniqueOrigins.map((orig) => (
                <option key={orig} value={orig}>
                  From: {orig}
                </option>
              ))}
            </select>

            <select
              value={filterDestination}
              onChange={(e) => setFilterDestination(e.target.value)}
              className="bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-2 text-xs text-slate-700 font-medium focus:outline-none focus:ring-2 focus:ring-blue-900"
            >
              <option value="all">Any Destination</option>
              {uniqueDestinations.map((dest) => (
                <option key={dest} value={dest}>
                  To: {dest}
                </option>
              ))}
            </select>

            {(filterOrigin !== 'all' || filterDestination !== 'all' || routeSearchKeyword) && (
              <button
                onClick={() => {
                  setFilterOrigin('all');
                  setFilterDestination('all');
                  setRouteSearchKeyword('');
                }}
                className="p-2 text-slate-500 hover:text-slate-800 bg-slate-100 rounded-lg"
                title="Reset route filters"
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Route, Direction, and Boarding Stop Selectors */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2 border-t border-slate-100">
          {/* Select Bus Route */}
          <div>
            <label className="block text-xs font-bold text-slate-800 mb-1.5 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <Bus className="w-3.5 h-3.5 text-blue-900" />
                <span>Selected Route ({filteredRouteOptions.length})</span>
              </span>
              {activeBus?.isVerified && (
                <span className="text-[10px] text-emerald-700 font-semibold flex items-center gap-0.5">
                  <Check className="w-3 h-3" /> Verified
                </span>
              )}
            </label>
            <select
              value={activeBus?.id || ''}
              onChange={(e) => {
                setSelectedRouteId(e.target.value);
                setSelectedBoardingStop('origin');
              }}
              className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-xs text-slate-900 font-semibold focus:outline-none focus:ring-2 focus:ring-blue-900"
            >
              {filteredRouteOptions.map((bus) => (
                <option key={bus.id} value={bus.id}>
                  Route {bus.routeNumber} — {bus.nameEn} ({bus.operator === 'sltb' ? 'SLTB' : 'Private'})
                </option>
              ))}
            </select>
          </div>

          {/* Direction Toggle */}
          <div>
            <label className="block text-xs font-bold text-slate-800 mb-1.5 flex items-center gap-1.5">
              <ArrowRight className="w-3.5 h-3.5 text-blue-900" />
              <span>Direction</span>
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => setDirection('forward')}
                className={`py-2 px-2 text-center rounded-lg border text-xs font-medium transition-colors truncate ${
                  direction === 'forward'
                    ? 'bg-blue-900 text-white border-blue-900 font-bold'
                    : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
                title={`Outbound: to ${activeBus?.destination}`}
              >
                Outbound: {activeBus?.destination.split(' ')[0]}
              </button>
              <button
                onClick={() => setDirection('return')}
                className={`py-2 px-2 text-center rounded-lg border text-xs font-medium transition-colors truncate ${
                  direction === 'return'
                    ? 'bg-blue-900 text-white border-blue-900 font-bold'
                    : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
                title={`Return: to ${activeBus?.startPoint}`}
              >
                Return: {activeBus?.startPoint.split(' ')[0]}
              </button>
            </div>
          </div>

          {/* Boarding Stop Selection */}
          <div>
            <label className="block text-xs font-bold text-slate-800 mb-1.5 flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-red-600" />
              <span>Boarding Stop / Intermediate Halt</span>
            </label>
            <select
              value={selectedBoardingStop}
              onChange={(e) => setSelectedBoardingStop(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-xs text-slate-900 font-medium focus:outline-none focus:ring-2 focus:ring-blue-900"
            >
              <option value="origin">Origin: {currentOriginName}</option>
              {routeStops.slice(1).map((stop) => (
                <option key={stop.order} value={stop.nameEn}>
                  {stop.order < 10 ? `0${stop.order}` : stop.order}. {stop.nameEn} (+{stop.estimatedMinutesFromStart || 0}m)
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Date and Time Range Filtering Strip */}
        <div className="pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3 text-xs">
          {/* Date Selector */}
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-700 flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-slate-500" />
              <span>Operating Date:</span>
            </span>

            <div className="flex items-center p-0.5 bg-slate-100 rounded-lg border border-slate-200">
              <button
                onClick={() => setDateMode('today')}
                className={`px-3 py-1 rounded-md transition-colors ${
                  dateMode === 'today'
                    ? 'bg-white text-blue-950 font-bold shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Today
              </button>
              <button
                onClick={() => setDateMode('tomorrow')}
                className={`px-3 py-1 rounded-md transition-colors ${
                  dateMode === 'tomorrow'
                    ? 'bg-white text-blue-950 font-bold shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Tomorrow
              </button>
              <button
                onClick={() => setDateMode('custom')}
                className={`px-3 py-1 rounded-md transition-colors ${
                  dateMode === 'custom'
                    ? 'bg-white text-blue-950 font-bold shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Custom Date
              </button>
            </div>

            {dateMode === 'custom' && (
              <input
                type="date"
                value={customDateStr}
                onChange={(e) => setCustomDateStr(e.target.value)}
                className="bg-white border border-slate-300 rounded-lg px-2 py-1 text-slate-900 font-mono text-xs"
              />
            )}

            <span className="text-[11px] font-semibold text-blue-900 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
              {targetDayOfWeekName}
            </span>
          </div>

          {/* Time of Day Range */}
          <div className="flex items-center gap-1.5">
            <span className="font-semibold text-slate-700">Departure Window:</span>
            <div className="flex items-center gap-1">
              {[
                { id: 'all', label: 'All Day' },
                { id: 'morning', label: 'Morning (05-12)' },
                { id: 'afternoon', label: 'Afternoon (12-17)' },
                { id: 'evening', label: 'Evening (17-21)' },
                { id: 'night', label: 'Overnight' },
              ].map((item) => (
                <button
                  key={item.id}
                  onClick={() => setTimeRange(item.id as any)}
                  className={`px-2 py-1 rounded text-xs transition-colors ${
                    timeRange === item.id
                      ? 'bg-slate-900 text-white font-bold'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* 3. WORKING NEXT SCHEDULED BUS CALCULATOR WIDGET */}
      <div className="bg-gradient-to-br from-slate-900 via-blue-950 to-slate-900 text-white rounded-2xl p-6 sm:p-8 shadow-xl border border-slate-800 relative overflow-hidden">
        {/* Background contour watermark */}
        <div className="absolute right-0 bottom-0 opacity-10 pointer-events-none translate-x-8 translate-y-8">
          <Bus className="w-80 h-80 text-white" />
        </div>

        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-3">
            <div className="flex flex-wrap items-center gap-2">
              <span className="bg-red-600 text-white text-xs font-mono font-bold px-2.5 py-0.5 rounded tracking-wider">
                Route {activeBus?.routeNumber}
              </span>
              <span className="text-xs bg-slate-800 text-slate-300 px-2 py-0.5 rounded border border-slate-700">
                {activeBus?.operatorName}
              </span>
              <span className="text-xs text-slate-400 font-mono">
                Reg: {activeBus?.registrationNumber}
              </span>
              {activeBus?.isDemoData && (
                <span className="text-[10px] bg-amber-500/20 text-amber-300 border border-amber-500/30 px-1.5 py-0.2 rounded font-mono">
                  [DEMO SCHEDULE]
                </span>
              )}
            </div>

            <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white">
              {currentOriginName} <ArrowRight className="inline w-5 h-5 text-red-400 mx-1" /> {currentDestName}
            </h2>

            <div className="flex flex-wrap items-center gap-3 text-xs text-slate-300">
              <span>
                Boarding Halt: <strong className="text-white">{selectedBoardingStop === 'origin' ? currentOriginName : selectedBoardingStop}</strong>
              </span>
              <span aria-hidden="true" className="text-slate-600">·</span>
              <span>Distance: <strong className="text-white">{activeBus?.distanceKm} km</strong></span>
              <span aria-hidden="true" className="text-slate-600">·</span>
              <span>Travel Time: <strong className="text-white">~{activeBus?.estimatedDuration}</strong></span>
            </div>

            {/* Frequency and Operating Interval */}
            <div className="flex flex-wrap items-center gap-2 text-xs pt-1">
              {activeBus?.frequencyPeak && (
                <span className="text-slate-300">
                  Peak Frequency: <strong className="text-emerald-400">{activeBus.frequencyPeak}</strong>
                </span>
              )}
              {activeBus?.frequencyOffPeak && (
                <>
                  <span aria-hidden="true" className="text-slate-600">·</span>
                  <span className="text-slate-300">
                    Off-Peak: <strong className="text-slate-200">{activeBus.frequencyOffPeak}</strong>
                  </span>
                </>
              )}
            </div>
          </div>

          {/* Live Countdown Display Box */}
          <div className="bg-slate-900/90 rounded-xl p-5 border border-slate-700/80 shadow-lg lg:min-w-[320px] text-center lg:text-right shrink-0">
            {hasTimetable ? (
              nextDepartureCalc ? (
                <div className="space-y-1.5">
                  <div className="flex items-center justify-center lg:justify-end gap-1.5 text-xs text-slate-400">
                    <Timer className="w-3.5 h-3.5 text-red-400 animate-pulse" />
                    <span className="font-semibold text-slate-200 uppercase tracking-wider">Next Scheduled Departure</span>
                  </div>

                  <div className="text-2xl sm:text-3xl font-extrabold font-mono tabular-nums text-white">
                    {nextDepartureCalc.departureTimeFormatted}
                  </div>

                  <div className="text-xs font-bold text-red-400">
                    Time Remaining: {nextDepartureCalc.statusLabel}
                  </div>

                  <div className="pt-2 mt-2 border-t border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
                    <span>Est. Destination Arrival:</span>
                    <strong className="text-white font-mono">{nextDepartureCalc.arrivalTimeFormatted}</strong>
                  </div>

                  {nextDepartureCalc.entry.isMidnightCrossing && (
                    <div className="text-[10px] text-amber-300 font-medium">
                      Overnight express service arrives following morning (+1 day).
                    </div>
                  )}
                </div>
              ) : (
                <div className="space-y-2 py-2">
                  <AlertCircle className="w-8 h-8 text-amber-400 mx-auto" />
                  <div className="text-xs font-bold text-white">No Upcoming Departures Today</div>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    Scheduled services have concluded for {targetDayOfWeekName}. First service resumes tomorrow morning at{' '}
                    <strong className="text-white font-mono">{activeFirstBus ? formatTime(activeFirstBus, timeFormat) : '05:30 AM'}</strong>.
                  </p>
                </div>
              )
            ) : (
              <div className="space-y-2 py-2">
                <Clock className="w-8 h-8 text-slate-500 mx-auto" />
                <div className="text-xs font-bold text-white">Timetable Not Registered Yet</div>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  Scheduled departure times for this route are pending regional depot verification.
                </p>
                {onOpenSubmitModal && (
                  <button
                    onClick={() => onOpenSubmitModal(activeBus)}
                    className="mt-2 inline-flex items-center gap-1 text-[11px] font-semibold text-blue-300 hover:text-white underline"
                  >
                    <PlusCircle className="w-3 h-3" />
                    <span>Submit Departure Times</span>
                  </button>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* 4. TIMETABLE METRICS STRIP (First Bus, Last Bus, Frequency, Days) */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
            <span>First Bus Scheduled</span>
            <Sun className="w-3.5 h-3.5 text-amber-500" />
          </div>
          <div className="text-lg font-bold font-mono tabular-nums text-slate-900">
            {activeFirstBus ? formatTime(activeFirstBus, timeFormat) : '05:30 AM'}
          </div>
          <span className="text-[11px] text-slate-400 block mt-0.5">Morning terminal departure</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
            <span>Last Bus Scheduled</span>
            <Moon className="w-3.5 h-3.5 text-indigo-500" />
          </div>
          <div className="text-lg font-bold font-mono tabular-nums text-slate-900">
            {activeLastBus ? formatTime(activeLastBus, timeFormat) : '21:00 PM'}
          </div>
          <span className="text-[11px] text-slate-400 block mt-0.5">Night terminal departure</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
            <span>Peak Interval</span>
            <Clock className="w-3.5 h-3.5 text-blue-600" />
          </div>
          <div className="text-sm font-bold text-slate-900">
            {activeBus?.frequencyPeak || 'Every 20-30 mins'}
          </div>
          <span className="text-[11px] text-slate-400 block mt-0.5">Morning & evening rush</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200">
          <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
            <span>Filtered Trips</span>
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
          </div>
          <div className="text-lg font-bold font-mono text-blue-900">
            {filteredTimetable.length} of {rawTimetable.length} Trips
          </div>
          <span className="text-[11px] text-slate-400 block mt-0.5">Operating on {targetDayOfWeekName}</span>
        </div>
      </div>

      {/* 5. TIMETABLE SCHEDULE TABLE WITH INTERMEDIATE HALTS */}
      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
        <div className="p-5 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-base font-bold text-slate-900">
              Timetable Schedule Table — Route {activeBus?.routeNumber}
            </h3>
            <span className="text-xs text-slate-500">
              Showing departure times from {currentOriginName} to {currentDestName} ({timeFormat} format)
            </span>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs bg-amber-50 text-amber-800 border border-amber-200 px-2 py-1 rounded font-medium">
              [DEMO TIMETABLE] Scheduled Times Only
            </span>
            <button
              onClick={() => onSelectBus(activeBus)}
              className="text-xs font-semibold text-blue-900 hover:text-blue-700 bg-blue-50 px-3 py-1.5 rounded-lg border border-blue-200 transition-colors"
            >
              View Route Profile →
            </button>
          </div>
        </div>

        {hasTimetable ? (
          filteredTimetable.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-100 text-slate-700 font-semibold border-b border-slate-200">
                  <tr>
                    <th className="py-3 px-4">Trip #</th>
                    <th className="py-3 px-4">Departure (Origin)</th>
                    {selectedBoardingStop !== 'origin' && (
                      <th className="py-3 px-4 text-blue-900 font-bold bg-blue-50">
                        At {selectedBoardingStop}
                      </th>
                    )}
                    <th className="py-3 px-4">Arrival (Dest)</th>
                    <th className="py-3 px-4">Operating Days</th>
                    <th className="py-3 px-4">Service Type</th>
                    <th className="py-3 px-4">Intermediate Timed Halts</th>
                    <th className="py-3 px-4">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredTimetable.map((row, idx) => {
                    // Calculate time at selected intermediate stop
                    const [h, m] = row.departureTime.split(':').map((v) => parseInt(v, 10));
                    const totalMin = (h * 60 + m + stopOffsetMinutes) % 1440;
                    const stopH = Math.floor(totalMin / 60);
                    const stopM = totalMin % 60;
                    const stopTimeFormatted = `${String(stopH).padStart(2, '0')}:${String(stopM).padStart(2, '0')}`;

                    return (
                      <tr key={row.id} className="hover:bg-slate-50 transition-colors">
                        <td className="py-3 px-4 font-mono text-slate-400">
                          #{idx + 1 < 10 ? `0${idx + 1}` : idx + 1}
                        </td>

                        <td className="py-3 px-4 font-mono font-bold text-slate-900 tabular-nums">
                          {formatTime(row.departureTime, timeFormat)}
                        </td>

                        {selectedBoardingStop !== 'origin' && (
                          <td className="py-3 px-4 font-mono font-bold text-blue-950 tabular-nums bg-blue-50/50">
                            {formatTime(stopTimeFormatted, timeFormat)}
                          </td>
                        )}

                        <td className="py-3 px-4 font-mono text-slate-700 tabular-nums">
                          {formatTime(row.arrivalTime, timeFormat)}
                          {row.isMidnightCrossing && (
                            <span className="text-[10px] text-amber-700 font-semibold ml-1.5 px-1.5 py-0.2 bg-amber-50 border border-amber-200 rounded">
                              +1 day
                            </span>
                          )}
                        </td>

                        <td className="py-3 px-4">
                          <span className="bg-slate-100 text-slate-700 px-2 py-0.5 rounded font-medium text-[11px] border border-slate-200">
                            {row.days.join(', ')}
                          </span>
                        </td>

                        <td className="py-3 px-4">
                          {row.isPeakHour ? (
                            <span className="text-red-700 font-semibold flex items-center gap-1">
                              <span className="w-1.5 h-1.5 rounded-full bg-red-600"></span>
                              Peak High-Demand
                            </span>
                          ) : (
                            <span className="text-slate-500">Regular Service</span>
                          )}
                        </td>

                        <td className="py-3 px-4">
                          {row.stopSchedules && row.stopSchedules.length > 0 ? (
                            <div className="space-y-0.5">
                              <span className="font-medium text-slate-800">
                                {row.stopSchedules.length} Timed Halts:
                              </span>
                              <div className="text-[11px] text-slate-500 font-mono line-clamp-1">
                                {row.stopSchedules
                                  .map((s) => `${s.stopName} (${formatTime(s.departureTime, timeFormat)})`)
                                  .join(' → ')}
                              </div>
                            </div>
                          ) : (
                            <span className="text-slate-400 text-[11px]">Standard corridor halts</span>
                          )}
                        </td>

                        <td className="py-3 px-4">
                          <span className="inline-flex items-center gap-1 text-[11px] text-emerald-700 font-medium">
                            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                            <span>Scheduled</span>
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="p-12 text-center text-slate-500 text-xs">
              <Clock className="w-10 h-10 text-slate-400 mx-auto mb-2" />
              <h4 className="font-bold text-slate-800 text-sm">No Timetable Entries for Selected Filters</h4>
              <p className="text-slate-500 mt-1 max-w-sm mx-auto">
                No services run during the selected departure window or operating day ({targetDayOfWeekName}). Try switching time range to &quot;All Day&quot; or selecting another day.
              </p>
            </div>
          )
        ) : (
          <div className="p-12 text-center text-slate-500 text-xs">
            <Clock className="w-10 h-10 text-slate-400 mx-auto mb-2" />
            <h4 className="font-bold text-slate-800 text-sm">Timetable Not Available Yet</h4>
            <p className="text-slate-500 mt-1 max-w-md mx-auto leading-relaxed">
              Official scheduled departure and arrival times for this route have not yet been registered or verified with regional transport authorities.
            </p>
            {onOpenSubmitModal && (
              <button
                onClick={() => onOpenSubmitModal(activeBus)}
                className="mt-4 inline-flex items-center gap-1.5 px-4 py-2 bg-blue-900 hover:bg-blue-800 text-white rounded-lg text-xs font-semibold transition-colors"
              >
                <PlusCircle className="w-3.5 h-3.5" />
                <span>Submit Timetable Information</span>
              </button>
            )}
          </div>
        )}

        {/* Timetable Advisory Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 text-xs text-slate-500 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-blue-900" />
            <span>Sri Lanka Transport Board (SLTB) & Provincial Passenger Transport Authorities Timetable Directory</span>
          </div>
          <span className="text-[11px] text-slate-400">
            Last administrative verification: {activeBus?.lastUpdated || '2026-10-14'}
          </span>
        </div>
      </div>
    </div>
  );
};
