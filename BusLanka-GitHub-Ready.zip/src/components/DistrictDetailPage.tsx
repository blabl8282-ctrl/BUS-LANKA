import React, { useState, useMemo } from 'react';
import {
  MapPin,
  ArrowLeft,
  Building2,
  Navigation,
  Bus,
  Search,
  Filter,
  RotateCcw,
  Compass,
} from 'lucide-react';
import { DistrictId, Language, BusRoute, BusType } from '../types/transit';
import { SRI_LANKA_DISTRICTS, SRI_LANKA_PROVINCES, DISTRICT_MAP, PROVINCE_MAP } from '../data/sriLankaProvinces';
import { BusCard } from './BusCard';
import { TRANSLATIONS } from '../i18n/translations';

interface DistrictDetailPageProps {
  districtId: DistrictId;
  currentLang: Language;
  buses: BusRoute[];
  onBackToDistricts: () => void;
  onSelectBus: (bus: BusRoute) => void;
  onOpenTimetable?: (bus: BusRoute) => void;
  onSwitchDistrict: (id: DistrictId) => void;
}

export const DistrictDetailPage: React.FC<DistrictDetailPageProps> = ({
  districtId,
  currentLang,
  buses,
  onBackToDistricts,
  onSelectBus,
  onOpenTimetable,
  onSwitchDistrict,
}) => {
  const t = TRANSLATIONS[currentLang];
  const district = DISTRICT_MAP.get(districtId) || SRI_LANKA_DISTRICTS[0];
  const province = PROVINCE_MAP.get(district.provinceId);

  // Filters within district page
  const [districtSearch, setDistrictSearch] = useState('');
  const [selectedDestination, setSelectedDestination] = useState<string>('all');
  const [selectedType, setSelectedType] = useState<BusType | 'all'>('all');

  // All buses traversing this district
  const districtBuses = useMemo(() => {
    return buses.filter((b) => b.districtsTraversed.includes(districtId));
  }, [buses, districtId]);

  // Unique destinations available from this district
  const uniqueDestinations = useMemo(() => {
    const dests = new Set<string>();
    districtBuses.forEach((b) => {
      dests.add(b.destination);
      dests.add(b.startPoint);
    });
    return Array.from(dests).sort();
  }, [districtBuses]);

  // Filtered district buses
  const filteredDistrictBuses = useMemo(() => {
    return districtBuses.filter((b) => {
      // Destination filter
      if (selectedDestination !== 'all') {
        if (b.destination !== selectedDestination && b.startPoint !== selectedDestination) {
          return false;
        }
      }

      // Bus Type filter
      if (selectedType !== 'all') {
        if (b.busType !== selectedType) {
          return false;
        }
      }

      // Text search (route number, keyword, stop)
      if (districtSearch.trim()) {
        const q = districtSearch.toLowerCase().trim();
        const matchesRoute = b.routeNumber.toLowerCase().includes(q);
        const matchesName = b.nameEn.toLowerCase().includes(q) || b.nameSi.toLowerCase().includes(q);
        const matchesStop = b.intermediateStops.some((s) => s.toLowerCase().includes(q));
        const matchesReg = b.registrationNumber.toLowerCase().includes(q);
        if (!matchesRoute && !matchesName && !matchesStop && !matchesReg) {
          return false;
        }
      }

      return true;
    });
  }, [districtBuses, selectedDestination, selectedType, districtSearch]);

  const districtName =
    currentLang === 'si'
      ? district.nameSi
      : currentLang === 'ta'
      ? district.nameTa
      : district.nameEn;

  const provinceName = province
    ? currentLang === 'si'
      ? province.nameSi
      : currentLang === 'ta'
      ? province.nameTa
      : province.nameEn
    : '';

  const districtDesc =
    currentLang === 'si'
      ? district.descriptionSi
      : currentLang === 'ta'
      ? district.descriptionTa
      : district.descriptionEn;

  const handleResetFilters = () => {
    setDistrictSearch('');
    setSelectedDestination('all');
    setSelectedType('all');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Top Navigation & Breadcrumbs */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
        <button
          onClick={onBackToDistricts}
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-blue-900 hover:text-blue-700 bg-white px-3 py-2 rounded-lg border border-slate-200 shadow-2xs transition-colors"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Back to All 25 Districts</span>
        </button>

        {/* Quick District Switcher Dropdown */}
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-500 font-medium">Switch District:</span>
          <select
            value={districtId}
            onChange={(e) => onSwitchDistrict(e.target.value as DistrictId)}
            className="text-xs bg-white border border-slate-300 rounded-lg py-1.5 px-3 text-slate-900 font-medium focus:outline-none focus:ring-1 focus:ring-blue-600 shadow-2xs"
          >
            {SRI_LANKA_DISTRICTS.map((d) => (
              <option key={d.id} value={d.id}>
                {d.nameEn} ({d.nameSi})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* District Hero Profile Header */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-xs mb-8">
        <div className="flex flex-col md:flex-row md:items-start justify-between gap-6">
          <div className="space-y-3 max-w-3xl">
            <div className="flex flex-wrap items-center gap-2">
              <span className="bg-blue-900 text-white text-xs font-bold px-2.5 py-0.5 rounded uppercase tracking-wider">
                {provinceName}
              </span>
              <span className="text-xs text-slate-500 font-medium">
                District of Sri Lanka
              </span>
            </div>

            <h1 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-slate-900 tracking-tight">
              {districtName} <span className="text-slate-400 font-medium text-xl sm:text-2xl">({district.nameEn})</span>
            </h1>

            <p className="text-slate-600 text-xs sm:text-sm leading-relaxed">
              {districtDesc}
            </p>

            {/* Quick Stats Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-4 border-t border-slate-100 text-xs">
              <div className="bg-slate-50 p-3 rounded-lg border border-slate-100">
                <span className="text-slate-400 block text-[11px]">Administrative Capital</span>
                <strong className="text-slate-900 font-semibold">{district.administrativeCapital}</strong>
              </div>

              <div className="bg-slate-50 p-3 rounded-lg border border-slate-100">
                <span className="text-slate-400 block text-[11px]">Major Arterial Highways</span>
                <span className="text-slate-800 font-medium line-clamp-1">
                  {district.majorHighways.slice(0, 2).join(', ')}
                </span>
              </div>

              <div className="bg-slate-50 p-3 rounded-lg border border-slate-100">
                <span className="text-slate-400 block text-[11px]">Available Bus Routes</span>
                <strong className="text-blue-900 font-mono font-bold text-sm">
                  {districtBuses.length} routes active
                </strong>
              </div>
            </div>
          </div>

          {/* Major Bus Stands in this District Card */}
          <div className="bg-slate-50 rounded-xl p-5 border border-slate-200 md:w-80 shrink-0 space-y-3">
            <div className="flex items-center gap-1.5 text-xs font-bold text-slate-900">
              <Building2 className="w-4 h-4 text-blue-900" />
              <span>Major Bus Stands in {district.nameEn}</span>
            </div>
            <ul className="space-y-1.5 text-xs text-slate-700">
              {district.majorBusStands.map((stand, i) => (
                <li key={i} className="flex items-start gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-red-500 shrink-0 mt-0.5" />
                  <span>{stand}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {/* District Page Filter Bar */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 mb-6 shadow-2xs flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-3 flex-1">
          {/* Search inside district */}
          <div className="relative flex items-center bg-slate-50 border border-slate-300 rounded-lg px-3 py-1.5 w-full sm:w-64">
            <Search className="w-3.5 h-3.5 text-slate-400 mr-2 shrink-0" />
            <input
              type="text"
              value={districtSearch}
              onChange={(e) => setDistrictSearch(e.target.value)}
              placeholder="Search route no, halt in district..."
              className="w-full text-xs text-slate-900 bg-transparent focus:outline-none"
            />
          </div>

          {/* Filter by Destination */}
          <select
            value={selectedDestination}
            onChange={(e) => setSelectedDestination(e.target.value)}
            className="text-xs bg-slate-50 border border-slate-300 rounded-lg py-1.5 px-3 text-slate-800 font-medium focus:outline-none"
          >
            <option value="all">All Destinations ({uniqueDestinations.length})</option>
            {uniqueDestinations.map((dest) => (
              <option key={dest} value={dest}>
                To / From: {dest}
              </option>
            ))}
          </select>

          {/* Filter by Bus Type */}
          <select
            value={selectedType}
            onChange={(e) => setSelectedType(e.target.value as BusType | 'all')}
            className="text-xs bg-slate-50 border border-slate-300 rounded-lg py-1.5 px-3 text-slate-800 font-medium focus:outline-none"
          >
            <option value="all">{t.allTypes}</option>
            <option value="normal">{t.normal}</option>
            <option value="semi_luxury">{t.semiLuxury}</option>
            <option value="luxury_ac">{t.luxuryAc}</option>
            <option value="expressway">{t.expressway}</option>
          </select>

          {(districtSearch || selectedDestination !== 'all' || selectedType !== 'all') && (
            <button
              onClick={handleResetFilters}
              className="flex items-center gap-1 text-xs text-red-600 hover:text-red-700 font-medium px-2 py-1 rounded"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Reset</span>
            </button>
          )}
        </div>

        <div className="text-xs text-slate-500 font-medium">
          Showing <span className="font-mono font-bold text-slate-900">{filteredDistrictBuses.length}</span> of{' '}
          <span className="font-mono">{districtBuses.length}</span> routes for {district.nameEn}
        </div>
      </div>

      {/* Bus Routes List for this District */}
      {filteredDistrictBuses.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredDistrictBuses.map((bus) => (
            <BusCard
              key={bus.id}
              bus={bus}
              currentLang={currentLang}
              onSelectBus={onSelectBus}
              onOpenTimetable={onOpenTimetable}
            />
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center max-w-md mx-auto my-8">
          <Compass className="w-10 h-10 text-slate-400 mx-auto mb-3" />
          <h3 className="text-base font-bold text-slate-900 mb-1">
            No Routes Matching Filters in {district.nameEn}
          </h3>
          <p className="text-xs text-slate-500 mb-4">
            Try clearing the destination or service type filter to view all available buses traversing {district.nameEn}.
          </p>
          <button
            onClick={handleResetFilters}
            className="px-4 py-2 bg-blue-900 hover:bg-blue-800 text-white rounded-lg text-xs font-semibold transition-colors"
          >
            Clear District Filters
          </button>
        </div>
      )}
    </div>
  );
};
