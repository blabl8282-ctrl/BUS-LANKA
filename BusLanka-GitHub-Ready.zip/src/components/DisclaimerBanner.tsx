import React, { useState } from 'react';
import { AlertTriangle, Info, X } from 'lucide-react';
import { Language } from '../types/transit';
import { TRANSLATIONS } from '../i18n/translations';

interface DisclaimerBannerProps {
  currentLang: Language;
}

export const DisclaimerBanner: React.FC<DisclaimerBannerProps> = ({ currentLang }) => {
  const [isDismissed, setIsDismissed] = useState(false);
  const t = TRANSLATIONS[currentLang];

  if (isDismissed) return null;

  return (
    <div className="bg-amber-50/90 border-b border-amber-200 text-amber-950 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2.5">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-start gap-2.5">
            <AlertTriangle className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <div className="flex flex-wrap items-center gap-2">
                <span className="font-semibold text-amber-900 uppercase tracking-wide text-[11px] bg-amber-200/80 px-1.5 py-0.5 rounded">
                  {t.demoDataNotice}
                </span>
                <span className="font-semibold text-amber-950">{t.disclaimerTitle}</span>
              </div>
              <p className="text-amber-800 leading-relaxed text-[11px]">
                {t.disclaimerText} <strong className="text-amber-950">{t.noBookingDisclaimer}</strong>
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsDismissed(true)}
            className="text-amber-700 hover:text-amber-950 p-1 shrink-0 rounded transition-colors"
            aria-label="Dismiss notice"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
