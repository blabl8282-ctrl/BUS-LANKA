import React from 'react';
import { Bus, Phone, Shield, ExternalLink, Heart } from 'lucide-react';
import { Language } from '../types/transit';
import { TRANSLATIONS } from '../i18n/translations';

interface FooterProps {
  currentLang: Language;
  onSelectTab: (tab: 'search' | 'districts' | 'district_detail' | 'stands' | 'timetables' | 'admin') => void;
}

export const Footer: React.FC<FooterProps> = ({ currentLang, onSelectTab }) => {
  const t = TRANSLATIONS[currentLang];

  return (
    <footer className="bg-slate-900 text-slate-400 text-xs border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          {/* Col 1: Brand & Purpose */}
          <div className="md:col-span-2 space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-blue-900 flex items-center justify-center text-white">
                <Bus className="w-4 h-4 text-red-400" />
              </div>
              <span className="text-lg font-bold text-white tracking-tight">
                Bus<span className="text-red-500">Lanka</span>
              </span>
            </div>
            <p className="text-slate-400 max-w-md text-xs leading-relaxed">
              Find Your Bus in Sri Lanka. Dedicated passenger bus route directory, scheduled timetables, and terminal contacts spanning all 9 provinces and 25 districts.
            </p>
            <div className="text-[11px] text-slate-500">
              <span className="font-semibold text-slate-400">Public Transport Advisory:</span> Schedules may fluctuate due to traffic density, weather, or operational delays. BusLanka does not conduct ticket sales or seat reservations.
            </div>
          </div>

          {/* Col 2: Navigation Links */}
          <div className="space-y-2">
            <span className="text-xs font-semibold text-white uppercase tracking-wider block">
              Transit Directory
            </span>
            <ul className="space-y-1.5 text-xs">
              <li>
                <button
                  onClick={() => onSelectTab('search')}
                  className="hover:text-white transition-colors"
                >
                  Routes & Schedules
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectTab('timetables')}
                  className="hover:text-white transition-colors"
                >
                  Timetables & Next Bus
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectTab('districts')}
                  className="hover:text-white transition-colors"
                >
                  All 25 Sri Lankan Districts
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectTab('stands')}
                  className="hover:text-white transition-colors"
                >
                  Bus Stand Directory
                </button>
              </li>
              <li>
                <button
                  onClick={() => onSelectTab('admin')}
                  className="hover:text-white transition-colors"
                >
                  Admin Verification Portal
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Sri Lanka Transit Hotlines */}
          <div className="space-y-2">
            <span className="text-xs font-semibold text-white uppercase tracking-wider block">
              Emergency Hotlines
            </span>
            <ul className="space-y-1.5 text-xs text-slate-300">
              <li className="flex items-center justify-between">
                <span>SLTB Inquiries:</span>
                <strong className="text-white font-mono">1958</strong>
              </li>
              <li className="flex items-center justify-between">
                <span>NTC Passenger Hotline:</span>
                <strong className="text-white font-mono">1955</strong>
              </li>
              <li className="flex items-center justify-between">
                <span>Southern Expressway:</span>
                <strong className="text-white font-mono">1969</strong>
              </li>
              <li className="flex items-center justify-between">
                <span>Police Tourist Division:</span>
                <strong className="text-white font-mono">1912</strong>
              </li>
            </ul>
          </div>
        </div>

        {/* Quiet Bottom Strip */}
        <div className="pt-6 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-500">
          <div>
            © {new Date().getFullYear()} BusLanka. All public transport information for civic utility.
          </div>
          <div className="flex items-center gap-4">
            <span>Sri Lanka Standard Time (Asia/Colombo UTC+5:30)</span>
            <span aria-hidden="true">·</span>
            <span>Trilingual Edition: සිංහල / English / தமிழ்</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
