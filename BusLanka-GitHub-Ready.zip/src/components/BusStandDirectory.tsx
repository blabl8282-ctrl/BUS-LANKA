import React, { useState } from 'react';
import { Building2, MapPin, Phone, Clock, ArrowRight, Search, ShieldCheck } from 'lucide-react';
import { BusStand, Language } from '../types/transit';
import { TRANSLATIONS } from '../i18n/translations';

interface BusStandDirectoryProps {
  busStands: BusStand[];
  currentLang: Language;
  onFilterByStand: (standName: string) => void;
}

export const BusStandDirectory: React.FC<BusStandDirectoryProps> = ({
  busStands,
  currentLang,
  onFilterByStand,
}) => {
  const [query, setQuery] = useState('');
  const t = TRANSLATIONS[currentLang];

  const filtered = busStands.filter((stand) => {
    const q = query.toLowerCase();
    return (
      stand.nameEn.toLowerCase().includes(q) ||
      stand.nameSi.toLowerCase().includes(q) ||
      stand.nameTa.toLowerCase().includes(q) ||
      stand.location.toLowerCase().includes(q) ||
      stand.operatorManagement.toLowerCase().includes(q)
    );
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
        <div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            {t.busStandsDirectory}
          </h2>
          <p className="text-slate-600 text-sm mt-1">
            Major bus terminals, interchanges, and depot offices across Sri Lanka with verified contacts and facilities.
          </p>
        </div>

        {/* Search stands */}
        <div className="w-full md:w-72">
          <div className="relative flex items-center bg-white border border-slate-300 rounded-lg px-3 py-2 shadow-2xs">
            <Search className="w-4 h-4 text-slate-400 mr-2 shrink-0" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search bus stand, city..."
              className="w-full text-xs text-slate-900 placeholder-slate-400 focus:outline-none"
            />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filtered.map((stand) => {
          const standName =
            currentLang === 'si'
              ? stand.nameSi
              : currentLang === 'ta'
              ? stand.nameTa
              : stand.nameEn;

          return (
            <div
              key={stand.id}
              className="bg-white rounded-xl border border-slate-200 p-5 shadow-xs hover:border-blue-300 transition-all flex flex-col justify-between"
            >
              <div>
                {/* Header */}
                <div className="flex items-start justify-between gap-3 mb-2">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-900 flex items-center justify-center shrink-0">
                      <Building2 className="w-4 h-4" />
                    </div>
                    <div>
                      <h3 className="text-base font-bold text-slate-900 leading-snug">
                        {standName}
                      </h3>
                      <span className="text-[11px] text-slate-400">
                        {stand.nameEn}
                      </span>
                    </div>
                  </div>
                  <span className="text-xs font-mono tabular-nums bg-slate-100 text-slate-700 px-2 py-0.5 rounded border border-slate-200 shrink-0">
                    {stand.baysCount} Bays
                  </span>
                </div>

                {/* Location */}
                <div className="flex items-center gap-1.5 text-xs text-slate-600 mt-2 mb-3">
                  <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <span>{stand.location}</span>
                </div>

                {/* Management and Hours */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs bg-slate-50 p-3 rounded-lg border border-slate-100 mb-3">
                  <div>
                    <span className="text-slate-400 block text-[11px]">Management Authority:</span>
                    <span className="font-medium text-slate-800">{stand.operatorManagement}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[11px]">Operating Hours:</span>
                    <span className="font-medium text-slate-800 flex items-center gap-1">
                      <Clock className="w-3 h-3 text-slate-400" />
                      {stand.operatingHours}
                    </span>
                  </div>
                </div>

                {/* Facilities */}
                <div className="mb-3">
                  <span className="text-[11px] font-semibold text-slate-500 block mb-1">
                    Terminal Facilities:
                  </span>
                  <div className="flex flex-wrap gap-1 text-[11px] text-slate-600">
                    {stand.facilities.map((fac, idx) => (
                      <span key={idx} className="bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                        {fac}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Key Connecting Routes */}
                <div>
                  <span className="text-[11px] font-semibold text-slate-500 block mb-1">
                    Key Connecting Routes:
                  </span>
                  <div className="text-xs text-slate-700 font-medium">
                    {stand.keyRoutes.join(' · ')}
                  </div>
                </div>
              </div>

              {/* Action Bar */}
              <div className="pt-4 mt-4 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2">
                <a
                  href={`tel:${stand.contactNumber}`}
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-700 hover:text-emerald-800 bg-emerald-50 px-2.5 py-1.5 rounded-lg border border-emerald-200 transition-colors"
                >
                  <Phone className="w-3 h-3 text-emerald-600" />
                  <span>{stand.contactNumber}</span>
                </a>

                <button
                  onClick={() => onFilterByStand(stand.nameEn.split(' ')[0])}
                  className="inline-flex items-center gap-1 text-xs font-semibold text-blue-900 hover:text-blue-800 hover:underline"
                >
                  <span>Find Buses From This Stand</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
