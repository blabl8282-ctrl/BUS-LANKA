import React from 'react';
import { Bus, Clock, MapPin, ArrowRight, ShieldCheck, PhoneCall } from 'lucide-react';
import { BusRoute, Language } from '../types/transit';
import { TRANSLATIONS } from '../i18n/translations';
import { getNextDeparture } from '../utils/colomboTime';

interface BusCardProps {
  bus: BusRoute;
  currentLang: Language;
  onSelectBus: (bus: BusRoute) => void;
  onOpenTimetable?: (bus: BusRoute) => void;
}

export const BusCard: React.FC<BusCardProps> = ({
  bus,
  currentLang,
  onSelectBus,
  onOpenTimetable,
}) => {
  const t = TRANSLATIONS[currentLang];
  const nextDeparture = getNextDeparture(bus.timetableForward);

  const routeTitle =
    currentLang === 'si' ? bus.nameSi : currentLang === 'ta' ? bus.nameTa : bus.nameEn;

  // Format type label
  const typeLabel =
    bus.busType === 'normal'
      ? t.normal
      : bus.busType === 'semi_luxury'
      ? t.semiLuxury
      : bus.busType === 'luxury_ac'
      ? t.luxuryAc
      : t.expressway;

  const operatorLabel = bus.operator === 'sltb' ? t.sltb : t.privateOp;

  // Primary photo or fallback
  const primaryPhoto = bus.photos.find((p) => p.view === 'front') || bus.photos[0];

  return (
    <div className="bg-white rounded-xl border border-slate-200 hover:border-slate-300 transition-all shadow-xs hover:shadow-md flex flex-col justify-between overflow-hidden">
      {/* Top Banner with Route Number and Next Departure */}
      <div className="p-5 pb-4">
        {/* Header row: Route number & next scheduled departure countdown */}
        <div className="flex items-start justify-between gap-3 mb-3">
          <div className="flex items-center gap-2.5">
            <div className="bg-blue-900 text-white font-mono font-bold text-base px-3 py-1 rounded-md tracking-wider shadow-2xs">
              {bus.routeNumber}
            </div>
            <div>
              <span className="text-xs font-semibold text-slate-900 block leading-tight">
                {operatorLabel}
              </span>
              <span className="text-[11px] text-slate-500 font-mono">
                Reg: {bus.registrationNumber}
              </span>
            </div>
          </div>

          {/* Next departure in Colombo Time */}
          {nextDeparture ? (
            <div
              className={`text-right ${onOpenTimetable ? 'cursor-pointer hover:opacity-80 transition-opacity' : ''}`}
              onClick={() => onOpenTimetable && onOpenTimetable(bus)}
              title={onOpenTimetable ? 'Click to open live countdown & full timetable' : undefined}
            >
              <div className="flex items-center justify-end gap-1 text-[11px] font-medium text-slate-500">
                <Clock className="w-3 h-3 text-red-500" />
                <span>Next Departure:</span>
              </div>
              <div className="text-xs font-bold text-slate-900 font-mono tabular-nums">
                {nextDeparture.formattedDeparture}
              </div>
              <div className="text-[10px] font-medium text-red-600">
                {nextDeparture.statusLabel}
              </div>
            </div>
          ) : (
            <div className="text-right text-[11px] text-slate-400">Schedule daily</div>
          )}
        </div>

        {/* Route Name and Destination */}
        <h3 className="text-base sm:text-lg font-bold text-slate-900 leading-snug mb-2 hover:text-blue-900 transition-colors cursor-pointer" onClick={() => onSelectBus(bus)}>
          {routeTitle}
        </h3>

        {/* Start Point & Destination Points */}
        <div className="flex items-center gap-1.5 text-xs text-slate-700 mb-3">
          <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
          <span className="font-medium text-slate-900">{bus.startPoint}</span>
          <ArrowRight className="w-3 h-3 text-slate-400 shrink-0" />
          <span className="font-medium text-slate-900">{bus.destination}</span>
        </div>

        {/* Zero-Pill Metadata Line */}
        <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 pt-2 border-t border-slate-100">
          <span className="font-medium text-slate-700">{typeLabel}</span>
          <span aria-hidden="true" className="text-slate-300">·</span>
          <span>{bus.distanceKm} km</span>
          <span aria-hidden="true" className="text-slate-300">·</span>
          <span>~{bus.estimatedDuration}</span>
          {bus.busStandName && (
            <>
              <span aria-hidden="true" className="text-slate-300">·</span>
              <span className="truncate max-w-[140px]">{bus.busStandName}</span>
            </>
          )}
        </div>

        {/* Key intermediate stops excerpt */}
        <div className="mt-3 text-[11px] text-slate-500 line-clamp-1">
          <strong className="text-slate-600 font-medium">Stops:</strong>{' '}
          {bus.intermediateStops.slice(0, 5).join(' · ')}
          {bus.intermediateStops.length > 5 && ` (+${bus.intermediateStops.length - 5} more)`}
        </div>
      </div>

      {/* Card Action & Hotline Bar */}
      <div className="bg-slate-50/80 px-5 py-3 border-t border-slate-100 flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          {bus.isVerified && (
            <span className="flex items-center gap-1 text-[11px] font-medium text-emerald-700">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>Verified Depot Info</span>
            </span>
          )}
          {bus.isDemoData && (
            <span className="text-[10px] text-slate-400 font-mono uppercase">
              [Demo Record]
            </span>
          )}
        </div>

        <button
          onClick={() => onSelectBus(bus)}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-blue-900 hover:bg-blue-800 text-white rounded-lg text-xs font-semibold transition-colors shrink-0"
        >
          <span>{t.viewDetails}</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
