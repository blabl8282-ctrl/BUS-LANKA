import React from 'react';
import { Search, Clock, ArrowRight, X } from 'lucide-react';
import { Language } from '../types/transit';
import { TRANSLATIONS } from '../i18n/translations';

interface SearchHeroProps {
  currentLang: Language;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  onPopularSelect: (query: string) => void;
  colomboTimeStr: string;
}

const POPULAR_SEARCHES = [
  { label: '01 Kandy - Colombo', query: '01' },
  { label: 'EX1-01 Galle Highway', query: 'EX1-01' },
  { label: '138 Homagama / Maharagama', query: '138' },
  { label: '87 Jaffna Express', query: '87' },
  { label: '187-E Airport Express', query: '187' },
  { label: '04 Anuradhapura', query: '04' },
];

export const SearchHero: React.FC<SearchHeroProps> = ({
  currentLang,
  searchQuery,
  onSearchChange,
  onPopularSelect,
  colomboTimeStr,
}) => {
  const t = TRANSLATIONS[currentLang];

  return (
    <div className="relative bg-slate-900 text-white overflow-hidden">
      {/* Background Image with Scrim */}
      <div className="absolute inset-0 pointer-events-none">
        <img
          src="./images/sltb_red_bus_hero_1791961706380.jpg"
          alt="Sri Lankan SLTB Transit Bus"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover opacity-25 filter brightness-75 contrast-110"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-900/80 to-slate-900/60" />
      </div>

      <div className="relative max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16 text-center">
        {/* Sri Lanka Time indicator */}
        <div className="inline-flex items-center gap-2 px-3 py-1 bg-slate-800/80 border border-slate-700 rounded-full text-xs text-slate-300 mb-6 backdrop-blur-xs">
          <Clock className="w-3.5 h-3.5 text-red-400" />
          <span>Colombo Time:</span>
          <span className="font-mono tabular-nums font-semibold text-white">{colomboTimeStr}</span>
          <span className="text-slate-500">(UTC+5:30)</span>
        </div>

        {/* Hero Title */}
        <h1
          className="text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight text-white mb-4"
          style={{ textWrap: 'balance' }}
        >
          {t.tagline}
        </h1>
        <p className="max-w-2xl mx-auto text-sm sm:text-base text-slate-300 mb-8 font-normal leading-relaxed">
          {t.subtitle}
        </p>

        {/* Search Bar Input Container */}
        <div className="max-w-3xl mx-auto mb-6">
          <div className="relative flex items-center shadow-xl rounded-xl overflow-hidden bg-white border-2 border-slate-200 focus-within:border-blue-600 transition-colors">
            <div className="pl-4 text-slate-400">
              <Search className="w-5 h-5" />
            </div>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder={t.searchPlaceholder}
              className="w-full py-4 px-3 text-slate-900 placeholder-slate-400 text-sm sm:text-base focus:outline-none"
            />
            {searchQuery && (
              <button
                onClick={() => onSearchChange('')}
                className="p-2 text-slate-400 hover:text-slate-600 mr-1"
                aria-label="Clear search"
              >
                <X className="w-4 h-4" />
              </button>
            )}
            <button
              onClick={() => {}}
              className="hidden sm:flex items-center gap-1.5 bg-blue-900 hover:bg-blue-800 text-white font-medium text-sm px-6 py-4 transition-colors whitespace-nowrap"
            >
              <span>Search</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Popular searches row */}
        <div className="flex flex-wrap items-center justify-center gap-2 text-xs text-slate-300">
          <span className="text-slate-400 font-medium">{t.popularSearches}:</span>
          {POPULAR_SEARCHES.map((item) => (
            <button
              key={item.query}
              onClick={() => onPopularSelect(item.query)}
              className="px-2.5 py-1 bg-slate-800/80 hover:bg-slate-700 text-slate-200 rounded-md border border-slate-700/80 transition-colors cursor-pointer text-xs"
            >
              {item.label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
