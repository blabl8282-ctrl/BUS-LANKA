import React, { useState } from 'react';
import {
  Shield,
  Key,
  LogOut,
  CheckCircle,
  XCircle,
  Plus,
  Trash2,
  Edit2,
  Bus,
  Clock,
  Database,
  AlertTriangle,
  RefreshCw,
  FileCheck,
  Check,
  X,
  ArrowRight,
} from 'lucide-react';
import { BusRoute, BusStand, PassengerSubmission, Language, BusType, OperatorType } from '../types/transit';
import { storageService } from '../services/storageService';
import { SRI_LANKA_DISTRICTS, SRI_LANKA_PROVINCES } from '../data/sriLankaProvinces';

interface AdminDashboardProps {
  buses: BusRoute[];
  busStands: BusStand[];
  submissions: PassengerSubmission[];
  currentLang: Language;
  isAuthenticated: boolean;
  onLogin: (passkey: string) => boolean;
  onLogout: () => void;
  onRefreshData: () => void;
  onEditBus: (bus: BusRoute) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  buses,
  busStands,
  submissions,
  isAuthenticated,
  onLogin,
  onLogout,
  onRefreshData,
  onEditBus,
}) => {
  const [passkeyInput, setPasskeyInput] = useState('');
  const [loginError, setLoginError] = useState(false);
  const [activeAdminTab, setActiveAdminTab] = useState<'submissions' | 'buses' | 'timetables' | 'stands' | 'database'>('submissions');
  const [adminNoteInput, setAdminNoteInput] = useState<Record<string, string>>({});
  const [actionSuccessMsg, setActionSuccessMsg] = useState('');

  // Add Bus Modal state
  const [isAddingBus, setIsAddingBus] = useState(false);
  const [newRouteNo, setNewRouteNo] = useState('');
  const [newNameEn, setNewNameEn] = useState('');
  const [newStart, setNewStart] = useState('');
  const [newDest, setNewDest] = useState('');
  const [newType, setNewType] = useState<BusType>('normal');
  const [newOperator, setNewOperator] = useState<OperatorType>('sltb');
  const [newRegNo, setNewRegNo] = useState('');
  const [newPhone, setNewPhone] = useState('+94 11 258 1120');
  const [newStops, setNewStops] = useState('Colombo Fort, Kelaniya, Kadawatha, Kandy');
  const [newDist, setNewDist] = useState<string>('colombo');

  // Timetable Management State
  const [selectedAdminRouteId, setSelectedAdminRouteId] = useState<string>(buses[0]?.id || '');
  const [selectedAdminDirection, setSelectedAdminDirection] = useState<'forward' | 'return'>('forward');
  const [isAddingTimetableEntry, setIsAddingTimetableEntry] = useState(false);
  const [editingTimetableEntry, setEditingTimetableEntry] = useState<import('../types/transit').TimetableEntry | null>(null);
  const [entryDepartureTime, setEntryDepartureTime] = useState('06:00');
  const [entryArrivalTime, setEntryArrivalTime] = useState('09:30');
  const [entryOrigin, setEntryOrigin] = useState('');
  const [entryDestination, setEntryDestination] = useState('');
  const [entryDays, setEntryDays] = useState('Daily');
  const [entryIsPeak, setEntryIsPeak] = useState(false);
  const [entryIsMidnight, setEntryIsMidnight] = useState(false);
  const [timetableValidationError, setTimetableValidationError] = useState('');

  const pendingSubmissions = submissions.filter((s) => s.status === 'pending');

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const success = onLogin(passkeyInput);
    if (!success) {
      setLoginError(true);
    } else {
      setLoginError(false);
      setPasskeyInput('');
    }
  };

  const handleApproveSubmission = (sub: PassengerSubmission) => {
    const note = adminNoteInput[sub.id] || 'Verified and approved by BusLanka transport administrator.';
    storageService.updateSubmissionStatus(sub.id, 'approved', note);
    setActionSuccessMsg(`Approved submission for Route ${sub.routeNumber}`);
    setTimeout(() => setActionSuccessMsg(''), 4000);
    onRefreshData();
  };

  const handleRejectSubmission = (sub: PassengerSubmission) => {
    const note = adminNoteInput[sub.id] || 'Insufficient depot verification details provided.';
    storageService.updateSubmissionStatus(sub.id, 'rejected', note);
    setActionSuccessMsg(`Rejected submission for Route ${sub.routeNumber}`);
    setTimeout(() => setActionSuccessMsg(''), 4000);
    onRefreshData();
  };

  const handleDeleteBus = (id: string, routeNumber: string) => {
    if (confirm(`Are you sure you want to delete bus Route ${routeNumber}?`)) {
      storageService.deleteBus(id);
      onRefreshData();
      setActionSuccessMsg(`Deleted bus Route ${routeNumber}`);
      setTimeout(() => setActionSuccessMsg(''), 3000);
    }
  };

  const handleToggleVerified = (bus: BusRoute) => {
    const updated = { ...bus, isVerified: !bus.isVerified };
    storageService.updateBus(updated);
    onRefreshData();
  };

  const handleCreateBus = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRouteNo || !newNameEn || !newStart || !newDest) return;

    const stopsArray = newStops.split(',').map((s) => s.trim()).filter(Boolean);

    const newBusRecord: BusRoute = {
      id: `bus-custom-${Date.now()}`,
      routeNumber: newRouteNo.trim(),
      nameEn: newNameEn.trim(),
      nameSi: newNameEn.trim(),
      nameTa: newNameEn.trim(),
      startPoint: newStart.trim(),
      destination: newDest.trim(),
      districtsTraversed: [newDist as any],
      provincesTraversed: ['western'],
      intermediateStops: stopsArray.length > 0 ? stopsArray : [newStart, newDest],
      roadsTraveled: ['Main Highway'],
      operator: newOperator,
      operatorName: newOperator === 'sltb' ? 'Sri Lanka Transport Board' : 'Private Operator (NTC)',
      registrationNumber: newRegNo.trim() || 'WP NA-9900',
      busType: newType,
      verifiedContactNumber: newPhone.trim(),
      estimatedDuration: '2 hrs',
      distanceKm: 75,
      timetableForward: [
        { id: `tf-${Date.now()}-1`, departureTime: '06:00', arrivalTime: '08:00', origin: newStart, destination: newDest, days: ['Daily'] },
        { id: `tf-${Date.now()}-2`, departureTime: '14:00', arrivalTime: '16:00', origin: newStart, destination: newDest, days: ['Daily'] },
      ],
      timetableReturn: [
        { id: `tr-${Date.now()}-1`, departureTime: '09:00', arrivalTime: '11:00', origin: newDest, destination: newStart, days: ['Daily'] },
      ],
      photos: [
        { view: 'front', url: './images/sltb_red_bus_hero_1791961706380.jpg', caption: 'Standard Transit Bus' },
      ],
      isVerified: true,
      isDemoData: true,
      lastUpdated: new Date().toISOString().split('T')[0],
    };

    storageService.addBus(newBusRecord);
    setIsAddingBus(false);
    setNewRouteNo('');
    setNewNameEn('');
    setNewStart('');
    setNewDest('');
    onRefreshData();
    setActionSuccessMsg(`Successfully added Route ${newRouteNo}`);
    setTimeout(() => setActionSuccessMsg(''), 4000);
  };

  const activeAdminBus = buses.find((b) => b.id === selectedAdminRouteId) || buses[0];
  const activeAdminTimetable = activeAdminBus
    ? selectedAdminDirection === 'forward'
      ? activeAdminBus.timetableForward
      : activeAdminBus.timetableReturn
    : [];

  const handleOpenAddTimetable = () => {
    setEditingTimetableEntry(null);
    setEntryDepartureTime('06:00');
    setEntryArrivalTime('09:30');
    setEntryOrigin(
      selectedAdminDirection === 'forward'
        ? activeAdminBus?.startPoint || ''
        : activeAdminBus?.destination || ''
    );
    setEntryDestination(
      selectedAdminDirection === 'forward'
        ? activeAdminBus?.destination || ''
        : activeAdminBus?.startPoint || ''
    );
    setEntryDays('Daily');
    setEntryIsPeak(false);
    setEntryIsMidnight(false);
    setTimetableValidationError('');
    setIsAddingTimetableEntry(true);
  };

  const handleOpenEditTimetable = (entry: import('../types/transit').TimetableEntry) => {
    setEditingTimetableEntry(entry);
    setEntryDepartureTime(entry.departureTime);
    setEntryArrivalTime(entry.arrivalTime);
    setEntryOrigin(entry.origin);
    setEntryDestination(entry.destination);
    setEntryDays(entry.days.join(', '));
    setEntryIsPeak(!!entry.isPeakHour);
    setEntryIsMidnight(!!entry.isMidnightCrossing);
    setTimetableValidationError('');
    setIsAddingTimetableEntry(true);
  };

  const handleSaveTimetableEntry = (e: React.FormEvent) => {
    e.preventDefault();
    setTimetableValidationError('');

    const timeRegex = /^([01]\d|2[0-3]):([0-5]\d)$/;
    if (!timeRegex.test(entryDepartureTime)) {
      setTimetableValidationError('Please enter a valid 24-hour departure time (HH:MM, e.g. 06:30 or 14:15).');
      return;
    }
    if (!timeRegex.test(entryArrivalTime)) {
      setTimetableValidationError('Please enter a valid 24-hour arrival time (HH:MM, e.g. 09:45 or 18:00).');
      return;
    }
    if (!entryOrigin.trim() || !entryDestination.trim()) {
      setTimetableValidationError('Origin and Destination points are required.');
      return;
    }

    // Duplicate check
    const duplicate = activeAdminTimetable.find(
      (t) => t.departureTime === entryDepartureTime && (!editingTimetableEntry || t.id !== editingTimetableEntry.id)
    );
    if (duplicate) {
      setTimetableValidationError(`A scheduled departure at ${entryDepartureTime} already exists for this route and direction.`);
      return;
    }

    const daysArray = entryDays.split(',').map((d) => d.trim()).filter(Boolean);

    if (editingTimetableEntry) {
      storageService.updateTimetableEntry(activeAdminBus.id, selectedAdminDirection, {
        ...editingTimetableEntry,
        departureTime: entryDepartureTime,
        arrivalTime: entryArrivalTime,
        origin: entryOrigin.trim(),
        destination: entryDestination.trim(),
        days: daysArray.length > 0 ? daysArray : ['Daily'],
        isPeakHour: entryIsPeak,
        isMidnightCrossing: entryIsMidnight,
      });
      setActionSuccessMsg(`Updated scheduled departure ${entryDepartureTime} for Route ${activeAdminBus.routeNumber}`);
    } else {
      storageService.addTimetableEntry(activeAdminBus.id, selectedAdminDirection, {
        departureTime: entryDepartureTime,
        arrivalTime: entryArrivalTime,
        origin: entryOrigin.trim(),
        destination: entryDestination.trim(),
        days: daysArray.length > 0 ? daysArray : ['Daily'],
        isPeakHour: entryIsPeak,
        isMidnightCrossing: entryIsMidnight,
      });
      setActionSuccessMsg(`Added new scheduled departure ${entryDepartureTime} to Route ${activeAdminBus.routeNumber}`);
    }

    setIsAddingTimetableEntry(false);
    setEditingTimetableEntry(null);
    setTimeout(() => setActionSuccessMsg(''), 4000);
    onRefreshData();
  };

  const handleDeleteTimetableEntry = (entryId: string, depTime: string) => {
    if (confirm(`Delete scheduled departure at ${depTime}?`)) {
      storageService.deleteTimetableEntry(activeAdminBus.id, selectedAdminDirection, entryId);
      setActionSuccessMsg(`Deleted scheduled departure at ${depTime}`);
      setTimeout(() => setActionSuccessMsg(''), 3000);
      onRefreshData();
    }
  };

  // If not authenticated, render Passkey Login
  if (!isAuthenticated) {
    return (
      <div className="max-w-md mx-auto my-16 px-4">
        <div className="bg-white rounded-2xl border border-slate-200 p-8 shadow-lg text-center">
          <div className="w-12 h-12 bg-blue-900 text-white rounded-xl flex items-center justify-center mx-auto mb-4">
            <Shield className="w-6 h-6 text-red-400" />
          </div>

          <h2 className="text-xl font-bold text-slate-900 mb-1">
            BusLanka Administration Portal
          </h2>
          <p className="text-xs text-slate-500 mb-6">
            Authorized transport officers only. Enter your administrator passkey to manage routes and passenger submissions.
          </p>

          <form onSubmit={handleLoginSubmit} className="space-y-4 text-left">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Admin Security Passkey
              </label>
              <div className="relative">
                <input
                  type="password"
                  value={passkeyInput}
                  onChange={(e) => setPasskeyInput(e.target.value)}
                  placeholder="Enter admin passkey (default: admin123)"
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg py-2.5 px-3 pl-9 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-900"
                  required
                />
                <Key className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              </div>
            </div>

            {loginError && (
              <p className="text-xs text-red-600 bg-red-50 p-2.5 rounded-lg border border-red-200">
                Invalid admin passkey. Please try again or use the demo key: <strong>admin123</strong>
              </p>
            )}

            <button
              type="submit"
              className="w-full py-2.5 bg-blue-900 hover:bg-blue-800 text-white text-xs font-bold rounded-lg transition-colors shadow-xs"
            >
              Sign In to Admin Panel
            </button>
          </form>

          <div className="mt-6 pt-4 border-t border-slate-100 text-[11px] text-slate-400">
            <span>Demo credentials: </span>
            <code className="bg-slate-100 px-1.5 py-0.5 rounded text-slate-700 font-mono">admin123</code>
          </div>
        </div>
      </div>
    );
  }

  // Authenticated Admin Dashboard View
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Top Admin Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2">
            <span className="bg-blue-900 text-white text-xs font-bold px-2 py-0.5 rounded uppercase tracking-wider">
              Admin Portal
            </span>
            <span className="text-xs text-emerald-600 font-semibold flex items-center gap-1">
              <CheckCircle className="w-3.5 h-3.5" /> Authenticated Session
            </span>
          </div>
          <h2 className="text-2xl font-extrabold text-slate-900 mt-1">
            Transport Operations & Content Management
          </h2>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsAddingBus(true)}
            className="flex items-center gap-1.5 px-3 py-2 bg-blue-900 hover:bg-blue-800 text-white rounded-lg text-xs font-semibold transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add New Bus Route</span>
          </button>

          <button
            onClick={onLogout}
            className="flex items-center gap-1.5 px-3 py-2 border border-slate-300 hover:bg-slate-100 text-slate-700 rounded-lg text-xs font-medium transition-colors"
          >
            <LogOut className="w-3.5 h-3.5 text-slate-500" />
            <span>Sign Out</span>
          </button>
        </div>
      </div>

      {/* Success Notification */}
      {actionSuccessMsg && (
        <div className="my-4 p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-lg text-xs font-medium flex items-center gap-2">
          <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{actionSuccessMsg}</span>
        </div>
      )}

      {/* KPI Stats Strip (Adhering to single elevation & anti-slop) */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 my-6">
        <div className="bg-white p-4 rounded-xl border border-slate-200">
          <span className="text-xs text-slate-500 block">Total Active Buses</span>
          <span className="text-2xl font-bold font-mono tabular-nums text-slate-900">
            {buses.length}
          </span>
          <span className="text-[11px] text-slate-400 block mt-0.5">Across 25 Districts</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200">
          <span className="text-xs text-slate-500 block">Pending Passenger Submissions</span>
          <span className="text-2xl font-bold font-mono tabular-nums text-amber-600">
            {pendingSubmissions.length}
          </span>
          <span className="text-[11px] text-slate-400 block mt-0.5">Awaiting moderation</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200">
          <span className="text-xs text-slate-500 block">Bus Terminals & Stands</span>
          <span className="text-2xl font-bold font-mono tabular-nums text-blue-900">
            {busStands.length}
          </span>
          <span className="text-[11px] text-slate-400 block mt-0.5">Directory Hubs</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200">
          <span className="text-xs text-slate-500 block">Database Storage</span>
          <span className="text-xs font-bold text-slate-800 block mt-1">Local Browser State</span>
          <span className="text-[11px] text-slate-400 block mt-0.5">Firebase Schema Ready</span>
        </div>
      </div>

      {/* Admin Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 mb-6">
        <button
          onClick={() => setActiveAdminTab('submissions')}
          className={`py-2 px-3 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap ${
            activeAdminTab === 'submissions'
              ? 'border-blue-900 text-blue-950 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          Passenger Submissions ({pendingSubmissions.length} Pending)
        </button>

        <button
          onClick={() => setActiveAdminTab('buses')}
          className={`py-2 px-3 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap ${
            activeAdminTab === 'buses'
              ? 'border-blue-900 text-blue-950 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          Manage Bus Routes ({buses.length})
        </button>

        <button
          onClick={() => setActiveAdminTab('timetables')}
          className={`py-2 px-3 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap ${
            activeAdminTab === 'timetables'
              ? 'border-blue-900 text-blue-950 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          Timetable Management
        </button>

        <button
          onClick={() => setActiveAdminTab('stands')}
          className={`py-2 px-3 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap ${
            activeAdminTab === 'stands'
              ? 'border-blue-900 text-blue-950 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          Bus Stands ({busStands.length})
        </button>

        <button
          onClick={() => setActiveAdminTab('database')}
          className={`py-2 px-3 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap ${
            activeAdminTab === 'database'
              ? 'border-blue-900 text-blue-950 font-bold'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          Cloud Backend / Firebase Setup
        </button>
      </div>

      {/* TAB 1: PASSENGER SUBMISSIONS */}
      {activeAdminTab === 'submissions' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-slate-900">
              Passenger Updates & Contributions Moderation Queue
            </h3>
            <span className="text-xs text-slate-500">
              Total {submissions.length} submissions recorded
            </span>
          </div>

          {submissions.length === 0 ? (
            <div className="bg-white p-8 rounded-xl border border-slate-200 text-center text-slate-500 text-xs">
              No submissions currently in the system.
            </div>
          ) : (
            <div className="space-y-3">
              {submissions.map((sub) => (
                <div
                  key={sub.id}
                  className={`bg-white rounded-xl border p-5 transition-colors ${
                    sub.status === 'pending'
                      ? 'border-amber-300 bg-amber-50/20'
                      : 'border-slate-200'
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3 mb-2">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-mono font-bold text-xs bg-blue-900 text-white px-2 py-0.5 rounded">
                          Route {sub.routeNumber}
                        </span>
                        <span className="text-xs font-semibold text-slate-800">
                          {sub.startPoint} → {sub.destination}
                        </span>
                        <span
                          className={`text-[11px] font-semibold px-2 py-0.5 rounded ${
                            sub.status === 'pending'
                              ? 'bg-amber-100 text-amber-800'
                              : sub.status === 'approved'
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-red-100 text-red-800'
                          }`}
                        >
                          {sub.status.toUpperCase()}
                        </span>
                      </div>
                      <div className="text-xs text-slate-500">
                        <span>Type: {sub.type.replace('_', ' ').toUpperCase()}</span>
                        <span aria-hidden="true" className="mx-1.5">·</span>
                        <span>Submitter: <strong>{sub.submitterName}</strong> ({sub.submitterContact})</span>
                        <span aria-hidden="true" className="mx-1.5">·</span>
                        <span className="font-mono">{sub.submissionDate}</span>
                      </div>
                    </div>
                  </div>

                  {/* Submission Detail */}
                  <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 text-xs text-slate-800 my-2">
                    <span className="font-semibold text-slate-700 block mb-1">Reported Information:</span>
                    <p className="leading-relaxed">{sub.suggestedChanges}</p>
                    {sub.photoUrl && (
                      <div className="mt-2 flex items-center gap-2">
                        <span className="font-medium text-slate-500">Attached Photo ({sub.photoView}):</span>
                        <a
                          href={sub.photoUrl}
                          target="_blank"
                          rel="noreferrer"
                          className="text-blue-800 underline font-mono text-[11px]"
                        >
                          View Image Link
                        </a>
                      </div>
                    )}
                  </div>

                  {sub.adminNotes && (
                    <div className="text-xs text-slate-600 bg-white p-2 rounded border border-slate-200 my-2">
                      <strong>Admin Verification Note:</strong> {sub.adminNotes}
                    </div>
                  )}

                  {/* Review Actions if Pending */}
                  {sub.status === 'pending' && (
                    <div className="pt-3 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3">
                      <input
                        type="text"
                        placeholder="Optional internal verification note..."
                        value={adminNoteInput[sub.id] || ''}
                        onChange={(e) =>
                          setAdminNoteInput({ ...adminNoteInput, [sub.id]: e.target.value })
                        }
                        className="text-xs bg-white border border-slate-300 rounded px-3 py-1.5 flex-1 max-w-md"
                      />

                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleRejectSubmission(sub)}
                          className="flex items-center gap-1 px-3 py-1.5 bg-red-50 hover:bg-red-100 text-red-700 rounded-lg text-xs font-semibold border border-red-200 transition-colors"
                        >
                          <X className="w-3.5 h-3.5" />
                          <span>Reject</span>
                        </button>
                        <button
                          onClick={() => handleApproveSubmission(sub)}
                          className="flex items-center gap-1 px-4 py-1.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-semibold transition-colors"
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>Approve & Verify</span>
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 2: MANAGE BUS ROUTES */}
      {activeAdminTab === 'buses' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-slate-900">
              Active Bus Routes Database ({buses.length})
            </h3>
            <button
              onClick={() => setIsAddingBus(true)}
              className="px-3 py-1.5 bg-blue-900 hover:bg-blue-800 text-white rounded-lg text-xs font-semibold transition-colors flex items-center gap-1"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Bus</span>
            </button>
          </div>

          <div className="border border-slate-200 rounded-xl overflow-hidden bg-white">
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-100 text-slate-700 font-semibold border-b border-slate-200">
                  <tr>
                    <th className="py-3 px-4">Route</th>
                    <th className="py-3 px-4">Origin → Destination</th>
                    <th className="py-3 px-4">Operator</th>
                    <th className="py-3 px-4">Type</th>
                    <th className="py-3 px-4">Reg No</th>
                    <th className="py-3 px-4">Hotline</th>
                    <th className="py-3 px-4">Verified</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {buses.map((bus) => (
                    <tr key={bus.id} className="hover:bg-slate-50 transition-colors">
                      <td className="py-2.5 px-4 font-mono font-bold text-blue-950">
                        {bus.routeNumber}
                      </td>
                      <td className="py-2.5 px-4 font-medium text-slate-900">
                        {bus.nameEn}
                      </td>
                      <td className="py-2.5 px-4 text-slate-600">
                        {bus.operator === 'sltb' ? 'SLTB' : 'Private'}
                      </td>
                      <td className="py-2.5 px-4 capitalize text-slate-600">
                        {bus.busType.replace('_', ' ')}
                      </td>
                      <td className="py-2.5 px-4 font-mono text-slate-700">
                        {bus.registrationNumber}
                      </td>
                      <td className="py-2.5 px-4 font-mono text-slate-700">
                        {bus.verifiedContactNumber}
                      </td>
                      <td className="py-2.5 px-4">
                        <button
                          onClick={() => handleToggleVerified(bus)}
                          className={`text-[11px] font-semibold px-2 py-0.5 rounded cursor-pointer ${
                            bus.isVerified
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-slate-100 text-slate-600'
                          }`}
                        >
                          {bus.isVerified ? 'Verified' : 'Unverified'}
                        </button>
                      </td>
                      <td className="py-2.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={() => onEditBus(bus)}
                            className="p-1 text-slate-500 hover:text-blue-900 transition-colors"
                            title="Edit details"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleDeleteBus(bus.id, bus.routeNumber)}
                            className="p-1 text-slate-400 hover:text-red-600 transition-colors"
                            title="Delete bus"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
      {/* TAB 3: TIMETABLE MANAGEMENT */}
      {activeAdminTab === 'timetables' && (
        <div className="space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
            <div>
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <Clock className="w-4 h-4 text-blue-900" />
                <span>Timetable & Departure Schedule Management</span>
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Add, edit, verify, and synchronize scheduled departure and arrival times for all public bus routes.
              </p>
            </div>

            <button
              onClick={handleOpenAddTimetable}
              className="px-4 py-2 bg-blue-900 hover:bg-blue-800 text-white rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 shadow-xs shrink-0"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Scheduled Departure</span>
            </button>
          </div>

          {/* Route & Direction Selector */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-white p-5 rounded-2xl border border-slate-200">
            <div>
              <label className="block text-xs font-bold text-slate-800 mb-1.5 flex items-center gap-1.5">
                <Bus className="w-3.5 h-3.5 text-blue-900" />
                <span>Select Route</span>
              </label>
              <select
                value={selectedAdminRouteId}
                onChange={(e) => setSelectedAdminRouteId(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2.5 text-xs text-slate-900 font-semibold focus:outline-none focus:ring-2 focus:ring-blue-900"
              >
                {buses.map((bus) => (
                  <option key={bus.id} value={bus.id}>
                    Route {bus.routeNumber} — {bus.nameEn} ({bus.operator === 'sltb' ? 'SLTB' : 'Private'} - {bus.registrationNumber})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-800 mb-1.5 flex items-center gap-1.5">
                <ArrowRight className="w-3.5 h-3.5 text-blue-900" />
                <span>Schedule Direction</span>
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedAdminDirection('forward')}
                  className={`py-2 px-3 text-center rounded-lg border text-xs font-medium transition-colors ${
                    selectedAdminDirection === 'forward'
                      ? 'bg-blue-900 text-white border-blue-900 font-bold'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  Outbound ({activeAdminBus?.destination.split(' ')[0]})
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedAdminDirection('return')}
                  className={`py-2 px-3 text-center rounded-lg border text-xs font-medium transition-colors ${
                    selectedAdminDirection === 'return'
                      ? 'bg-blue-900 text-white border-blue-900 font-bold'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  Return ({activeAdminBus?.startPoint.split(' ')[0]})
                </button>
              </div>
            </div>
          </div>

          {/* Route Overview Metrics */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="bg-white p-4 rounded-xl border border-slate-200">
              <span className="text-slate-500 text-xs block mb-1">Route & Operator</span>
              <div className="text-sm font-bold text-slate-900">
                Route {activeAdminBus?.routeNumber} ({activeAdminBus?.operator.toUpperCase()})
              </div>
              <span className="text-[11px] text-slate-400 font-mono">Reg: {activeAdminBus?.registrationNumber}</span>
            </div>

            <div className="bg-white p-4 rounded-xl border border-slate-200">
              <span className="text-slate-500 text-xs block mb-1">First Bus (Morning)</span>
              <div className="text-sm font-bold font-mono text-slate-900">
                {selectedAdminDirection === 'forward' ? activeAdminBus?.firstBusForward || '05:30' : activeAdminBus?.firstBusReturn || '05:00'}
              </div>
              <span className="text-[11px] text-slate-400">Terminal opening run</span>
            </div>

            <div className="bg-white p-4 rounded-xl border border-slate-200">
              <span className="text-slate-500 text-xs block mb-1">Last Bus (Night)</span>
              <div className="text-sm font-bold font-mono text-slate-900">
                {selectedAdminDirection === 'forward' ? activeAdminBus?.lastBusForward || '21:00' : activeAdminBus?.lastBusReturn || '19:00'}
              </div>
              <span className="text-[11px] text-slate-400">Terminal closing run</span>
            </div>

            <div className="bg-white p-4 rounded-xl border border-slate-200">
              <span className="text-slate-500 text-xs block mb-1">Registered Departures</span>
              <div className="text-sm font-bold font-mono text-blue-900">
                {activeAdminTimetable.length} Scheduled Trips
              </div>
              <span className="text-[11px] text-slate-400">Direction: {selectedAdminDirection}</span>
            </div>
          </div>

          {/* Departures Table */}
          <div className="border border-slate-200 rounded-xl overflow-hidden bg-white shadow-2xs">
            <div className="p-4 bg-slate-50 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <h4 className="text-xs font-bold text-slate-800">
                Departure Timetable ({activeAdminTimetable.length} Runs)
              </h4>
              <span className="text-[11px] text-slate-500">
                Origin: <strong>{selectedAdminDirection === 'forward' ? activeAdminBus?.startPoint : activeAdminBus?.destination}</strong> → Destination: <strong>{selectedAdminDirection === 'forward' ? activeAdminBus?.destination : activeAdminBus?.startPoint}</strong>
              </span>
            </div>

            {activeAdminTimetable.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full text-xs text-left">
                  <thead className="bg-slate-100 text-slate-700 font-semibold border-b border-slate-200">
                    <tr>
                      <th className="py-2.5 px-4">#</th>
                      <th className="py-2.5 px-4">Departure (24h)</th>
                      <th className="py-2.5 px-4">Arrival (24h)</th>
                      <th className="py-2.5 px-4">Origin Point</th>
                      <th className="py-2.5 px-4">Destination Point</th>
                      <th className="py-2.5 px-4">Operating Days</th>
                      <th className="py-2.5 px-4">Service Type</th>
                      <th className="py-2.5 px-4">Overnight (+1)</th>
                      <th className="py-2.5 px-4">Timed Halts</th>
                      <th className="py-2.5 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {activeAdminTimetable.map((row, idx) => (
                      <tr key={row.id} className="hover:bg-slate-50 transition-colors">
                        <td className="py-2.5 px-4 font-mono text-slate-400">
                          #{idx + 1 < 10 ? `0${idx + 1}` : idx + 1}
                        </td>
                        <td className="py-2.5 px-4 font-mono font-bold text-slate-900">
                          {row.departureTime}
                        </td>
                        <td className="py-2.5 px-4 font-mono text-slate-700">
                          {row.arrivalTime}
                        </td>
                        <td className="py-2.5 px-4 text-slate-800">{row.origin}</td>
                        <td className="py-2.5 px-4 text-slate-800">{row.destination}</td>
                        <td className="py-2.5 px-4">
                          <span className="bg-slate-100 text-slate-700 px-2 py-0.5 rounded text-[11px] font-medium border border-slate-200">
                            {row.days.join(', ')}
                          </span>
                        </td>
                        <td className="py-2.5 px-4">
                          {row.isPeakHour ? (
                            <span className="text-red-700 font-semibold text-[11px] bg-red-50 px-2 py-0.5 rounded border border-red-200">
                              Peak
                            </span>
                          ) : (
                            <span className="text-slate-500 text-[11px]">Regular</span>
                          )}
                        </td>
                        <td className="py-2.5 px-4">
                          {row.isMidnightCrossing ? (
                            <span className="text-amber-800 font-semibold text-[11px] bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                              Overnight (+1)
                            </span>
                          ) : (
                            <span className="text-slate-400 text-[11px]">Same Day</span>
                          )}
                        </td>
                        <td className="py-2.5 px-4 text-slate-600 font-mono text-[11px]">
                          {row.stopSchedules?.length ? `${row.stopSchedules.length} Halts` : 'Corridor'}
                        </td>
                        <td className="py-2.5 px-4 text-right">
                          <div className="flex items-center justify-end gap-2">
                            <button
                              type="button"
                              onClick={() => handleOpenEditTimetable(row)}
                              className="p-1 text-slate-500 hover:text-blue-900 transition-colors"
                              title="Edit departure"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleDeleteTimetableEntry(row.id, row.departureTime)}
                              className="p-1 text-slate-400 hover:text-red-600 transition-colors"
                              title="Delete departure"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="p-8 text-center text-slate-500 text-xs">
                <Clock className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                <h5 className="font-bold text-slate-800">No Timetable Entries for this Direction</h5>
                <p className="text-slate-500 mt-1">
                  Click &quot;Add Scheduled Departure&quot; above to create a departure schedule.
                </p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 4: BUS STANDS */}
      {activeAdminTab === 'stands' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-slate-900">
              Bus Terminal Hubs Directory ({busStands.length})
            </h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {busStands.map((stand) => (
              <div key={stand.id} className="bg-white p-4 rounded-xl border border-slate-200">
                <div className="flex items-start justify-between gap-2 mb-1">
                  <h4 className="font-bold text-slate-900 text-sm">{stand.nameEn}</h4>
                  <span className="font-mono text-xs bg-slate-100 px-2 py-0.5 rounded">
                    {stand.baysCount} Bays
                  </span>
                </div>
                <div className="text-xs text-slate-500 mb-2">{stand.location}</div>
                <div className="text-xs text-slate-700">
                  <span>Contact: <strong>{stand.contactNumber}</strong></span>
                  <span className="mx-2">·</span>
                  <span>Authority: {stand.operatorManagement}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 4: DATABASE & FIREBASE CONFIG */}
      {activeAdminTab === 'database' && (
        <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-4 text-xs text-slate-800">
          <div className="flex items-center gap-2 text-blue-900 font-bold text-base">
            <Database className="w-5 h-5" />
            <span>Database Architecture & Cloud Integration Status</span>
          </div>

          <p className="text-slate-600 leading-relaxed">
            BusLanka is engineered with a strict relational and document data model structured for Sri Lanka's transit ecosystem (Districts, Provinces, Buses, Routes, Stops, Timetables, Bus Stands, Photos, Contacts, Users, and Passenger Submissions).
          </p>

          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-slate-900">Current Storage State:</span>
              <span className="bg-emerald-100 text-emerald-800 font-semibold px-2 py-0.5 rounded">
                Active In-Browser LocalStorage Sync
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="font-semibold text-slate-900">Permanent Cloud Persistence:</span>
              <span className="text-amber-800 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                Ready for Firebase / Supabase Free-Tier Provisioning
              </span>
            </div>
          </div>

          <div className="border-t border-slate-200 pt-4 space-y-2">
            <h4 className="font-bold text-slate-900">Firebase Firestore Integration Blueprint:</h4>
            <ul className="list-disc list-inside space-y-1 text-slate-600">
              <li>Collections: <code>buses</code>, <code>bus_stands</code>, <code>submissions</code>, <code>districts</code>, <code>provinces</code></li>
              <li>Security Rules: Public read access for verified routes and bus stands; write access restricted to passenger submission creation; admin write/approval operations protected by Firebase Auth custom claims (<code>request.auth.token.role == 'admin'</code>).</li>
              <li>Timetable sub-collections for high frequency schedules and peak hour flags.</li>
            </ul>
          </div>

          <div className="pt-2">
            <button
              onClick={() => {
                if (confirm('Reset application data back to default factory demo routes? This will clear locally added custom records.')) {
                  storageService.resetAllToDefaults();
                  onRefreshData();
                  setActionSuccessMsg('Reset all records to factory defaults.');
                  setTimeout(() => setActionSuccessMsg(''), 3000);
                }
              }}
              className="flex items-center gap-1.5 px-3 py-2 bg-red-50 hover:bg-red-100 text-red-700 rounded-lg font-semibold border border-red-200 transition-colors"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Reset Local Database to Default Demo Routes</span>
            </button>
          </div>
        </div>
      )}

      {/* CREATE NEW BUS MODAL */}
      {isAddingBus && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="bg-white rounded-2xl max-w-xl w-full p-6 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 mb-4">
              <h3 className="text-base font-bold text-slate-900">Add New Bus Route</h3>
              <button
                onClick={() => setIsAddingBus(false)}
                className="text-slate-400 hover:text-slate-700"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateBus} className="space-y-3 text-xs text-slate-800">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1">Route Number *</label>
                  <input
                    type="text"
                    required
                    value={newRouteNo}
                    onChange={(e) => setNewRouteNo(e.target.value)}
                    placeholder="e.g. 100, 122, EX2-01"
                    className="w-full border border-slate-300 rounded p-2 text-slate-900 font-mono"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1">Route Title (English) *</label>
                  <input
                    type="text"
                    required
                    value={newNameEn}
                    onChange={(e) => setNewNameEn(e.target.value)}
                    placeholder="e.g. Colombo - Panadura"
                    className="w-full border border-slate-300 rounded p-2 text-slate-900"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1">Origin *</label>
                  <input
                    type="text"
                    required
                    value={newStart}
                    onChange={(e) => setNewStart(e.target.value)}
                    placeholder="e.g. Pettah Fort"
                    className="w-full border border-slate-300 rounded p-2 text-slate-900"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1">Destination *</label>
                  <input
                    type="text"
                    required
                    value={newDest}
                    onChange={(e) => setNewDest(e.target.value)}
                    placeholder="e.g. Panadura Town"
                    className="w-full border border-slate-300 rounded p-2 text-slate-900"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold mb-1">Bus Type</label>
                  <select
                    value={newType}
                    onChange={(e) => setNewType(e.target.value as BusType)}
                    className="w-full border border-slate-300 rounded p-2 text-slate-900"
                  >
                    <option value="normal">Normal</option>
                    <option value="semi_luxury">Semi-Luxury</option>
                    <option value="luxury_ac">Luxury / AC</option>
                    <option value="expressway">Expressway</option>
                  </select>
                </div>
                <div>
                  <label className="block font-semibold mb-1">Operator</label>
                  <select
                    value={newOperator}
                    onChange={(e) => setNewOperator(e.target.value as OperatorType)}
                    className="w-full border border-slate-300 rounded p-2 text-slate-900"
                  >
                    <option value="sltb">SLTB</option>
                    <option value="private">Private (NTC)</option>
                  </select>
                </div>
                <div>
                  <label className="block font-semibold mb-1">Primary District</label>
                  <select
                    value={newDist}
                    onChange={(e) => setNewDist(e.target.value)}
                    className="w-full border border-slate-300 rounded p-2 text-slate-900"
                  >
                    {SRI_LANKA_DISTRICTS.map((d) => (
                      <option key={d.id} value={d.id}>
                        {d.nameEn}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1">Bus Reg. No</label>
                  <input
                    type="text"
                    value={newRegNo}
                    onChange={(e) => setNewRegNo(e.target.value)}
                    placeholder="e.g. WP ND-1288"
                    className="w-full border border-slate-300 rounded p-2 text-slate-900 font-mono"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1">Verified Hotline</label>
                  <input
                    type="text"
                    value={newPhone}
                    onChange={(e) => setNewPhone(e.target.value)}
                    placeholder="+94 11 258 1120"
                    className="w-full border border-slate-300 rounded p-2 text-slate-900"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold mb-1">
                  Intermediate Stops (comma separated)
                </label>
                <input
                  type="text"
                  value={newStops}
                  onChange={(e) => setNewStops(e.target.value)}
                  placeholder="Stop 1, Stop 2, Stop 3"
                  className="w-full border border-slate-300 rounded p-2 text-slate-900"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsAddingBus(false)}
                  className="px-3 py-2 border border-slate-300 rounded text-slate-600 hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-900 hover:bg-blue-800 text-white font-semibold rounded"
                >
                  Save Bus Route
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ADD / EDIT TIMETABLE ENTRY MODAL */}
      {isAddingTimetableEntry && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 mb-4">
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  {editingTimetableEntry ? 'Edit Scheduled Departure' : 'Add New Scheduled Departure'}
                </h3>
                <p className="text-xs text-slate-500">
                  Route {activeAdminBus?.routeNumber} · {selectedAdminDirection === 'forward' ? 'Outbound' : 'Return'}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setIsAddingTimetableEntry(false)}
                className="text-slate-400 hover:text-slate-700"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {timetableValidationError && (
              <div className="mb-4 bg-red-50 border border-red-200 text-red-800 p-3 rounded-lg text-xs flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-red-600" />
                <span>{timetableValidationError}</span>
              </div>
            )}

            <form onSubmit={handleSaveTimetableEntry} className="space-y-4 text-xs text-slate-800">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1">Departure Time (24h HH:MM) *</label>
                  <input
                    type="text"
                    required
                    value={entryDepartureTime}
                    onChange={(e) => setEntryDepartureTime(e.target.value)}
                    placeholder="06:30"
                    pattern="^([01]\d|2[0-3]):([0-5]\d)$"
                    title="24-hour time format (00:00 - 23:59)"
                    className="w-full border border-slate-300 rounded p-2 text-slate-900 font-mono text-sm"
                  />
                  <span className="text-[10px] text-slate-400 block mt-0.5">e.g. 05:30, 14:15, 21:00</span>
                </div>
                <div>
                  <label className="block font-semibold mb-1">Arrival Time (24h HH:MM) *</label>
                  <input
                    type="text"
                    required
                    value={entryArrivalTime}
                    onChange={(e) => setEntryArrivalTime(e.target.value)}
                    placeholder="09:45"
                    pattern="^([01]\d|2[0-3]):([0-5]\d)$"
                    title="24-hour time format (00:00 - 23:59)"
                    className="w-full border border-slate-300 rounded p-2 text-slate-900 font-mono text-sm"
                  />
                  <span className="text-[10px] text-slate-400 block mt-0.5">e.g. 09:00, 17:30, 00:30</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1">Origin Terminal *</label>
                  <input
                    type="text"
                    required
                    value={entryOrigin}
                    onChange={(e) => setEntryOrigin(e.target.value)}
                    placeholder="e.g. Colombo Fort"
                    className="w-full border border-slate-300 rounded p-2 text-slate-900"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1">Destination Terminal *</label>
                  <input
                    type="text"
                    required
                    value={entryDestination}
                    onChange={(e) => setEntryDestination(e.target.value)}
                    placeholder="e.g. Kandy Goodshed"
                    className="w-full border border-slate-300 rounded p-2 text-slate-900"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold mb-1">Operating Days (comma separated)</label>
                <input
                  type="text"
                  required
                  value={entryDays}
                  onChange={(e) => setEntryDays(e.target.value)}
                  placeholder="Daily or Mon-Fri, Weekends"
                  className="w-full border border-slate-300 rounded p-2 text-slate-900"
                />
                <span className="text-[10px] text-slate-400 block mt-0.5">
                  Options: Daily, Mon-Fri, Weekends, Monday, Friday, Sun-Thu
                </span>
              </div>

              <div className="bg-slate-50 p-3 rounded-lg border border-slate-200 space-y-2">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={entryIsPeak}
                    onChange={(e) => setEntryIsPeak(e.target.checked)}
                    className="rounded border-slate-300 text-blue-900"
                  />
                  <span className="font-semibold text-slate-900">High-Demand Peak Hour Service</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={entryIsMidnight}
                    onChange={(e) => setEntryIsMidnight(e.target.checked)}
                    className="rounded border-slate-300 text-blue-900"
                  />
                  <span className="font-semibold text-slate-900">Overnight Midnight Crossing (+1 day arrival)</span>
                </label>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsAddingTimetableEntry(false)}
                  className="px-3 py-2 border border-slate-300 rounded text-slate-600 hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-900 hover:bg-blue-800 text-white font-semibold rounded"
                >
                  {editingTimetableEntry ? 'Save Changes' : 'Add Departure'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
