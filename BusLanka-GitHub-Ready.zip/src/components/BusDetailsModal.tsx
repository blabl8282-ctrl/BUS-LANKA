import React, { useState, useEffect } from 'react';
import {
  X,
  Clock,
  Phone,
  MapPin,
  ShieldCheck,
  Calendar,
  AlertTriangle,
  ArrowRight,
  Bus,
  CheckCircle,
  ExternalLink,
} from 'lucide-react';
import { BusRoute, Language, BusPhoto, RouteStop } from '../types/transit';
import { TRANSLATIONS } from '../i18n/translations';
import { getNextDeparture, format12Hour } from '../utils/colomboTime';

interface BusDetailsModalProps {
  bus: BusRoute | null;
  currentLang: Language;
  onClose: () => void;
  onOpenSubmitModal: (bus: BusRoute) => void;
  onOpenTimetable?: (bus: BusRoute) => void;
  colomboTimeStr: string;
}

export const BusDetailsModal: React.FC<BusDetailsModalProps> = ({
  bus,
  currentLang,
  onClose,
  onOpenSubmitModal,
  onOpenTimetable,
  colomboTimeStr,
}) => {
  const [selectedPhotoView, setSelectedPhotoView] = useState<'front' | 'rear' | 'side' | 'interior'>('front');
  const [timetableTab, setTimetableTab] = useState<'forward' | 'return'>('forward');

  // Handle escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  if (!bus) return null;

  const t = TRANSLATIONS[currentLang];
  const nextDeparture = getNextDeparture(bus.timetableForward);
  const routeTitle =
    currentLang === 'si' ? bus.nameSi : currentLang === 'ta' ? bus.nameTa : bus.nameEn;

  const typeLabel =
    bus.busType === 'normal'
      ? t.normal
      : bus.busType === 'semi_luxury'
      ? t.semiLuxury
      : bus.busType === 'luxury_ac'
      ? t.luxuryAc
      : t.expressway;

  const currentPhoto =
    bus.photos.find((p) => p.view === selectedPhotoView) || bus.photos[0];

  const activeTimetable =
    timetableTab === 'forward' ? bus.timetableForward : bus.timetableReturn;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 md:p-6">
      <div className="bg-white rounded-2xl max-w-4xl w-full shadow-2xl border border-slate-200 overflow-hidden my-6 max-h-[92vh] flex flex-col">
        {/* Modal Header */}
        <div className="bg-slate-900 text-white p-5 sm:p-6 flex items-start justify-between gap-4 border-b border-slate-800">
          <div>
            <div className="flex flex-wrap items-center gap-2 mb-2">
              <span className="bg-red-600 text-white font-mono font-bold text-base px-2.5 py-0.5 rounded shadow-xs">
                Route {bus.routeNumber}
              </span>
              <span className="text-xs font-semibold bg-slate-800 text-slate-200 px-2.5 py-0.5 rounded border border-slate-700">
                {typeLabel}
              </span>
              {bus.isVerified && (
                <span className="flex items-center gap-1 text-xs text-emerald-400 font-medium">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>Depot Verified</span>
                </span>
              )}
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
              {routeTitle}
            </h2>
            <div className="flex items-center gap-2 text-xs text-slate-300 mt-1">
              <span>{bus.operatorName}</span>
              <span aria-hidden="true">·</span>
              <span className="font-mono">Reg: {bus.registrationNumber}</span>
              <span aria-hidden="true">·</span>
              <span>Updated: {bus.lastUpdated}</span>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white bg-slate-800/80 hover:bg-slate-700 p-2 rounded-lg transition-colors"
            aria-label="Close dialog"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Live Colombo Time Departure Banner */}
        <div className="bg-blue-50 border-b border-blue-100 px-6 py-3 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 text-blue-950 font-medium">
            <Clock className="w-4 h-4 text-blue-700" />
            <span>Sri Lanka Time: <strong className="font-mono tabular-nums">{colomboTimeStr}</strong></span>
          </div>

          {nextDeparture ? (
            <div className="flex items-center gap-2 text-blue-900 font-medium">
              <span className="text-slate-600">Next Scheduled Departure:</span>
              <span className="font-mono font-bold text-blue-950 bg-white px-2 py-0.5 rounded border border-blue-200">
                {nextDeparture.formattedDeparture}
              </span>
              <span className="text-red-600 font-bold">({nextDeparture.statusLabel})</span>
            </div>
          ) : (
            <span className="text-slate-500">Service operates daily</span>
          )}
        </div>

        {/* Modal Scrollable Content */}
        <div className="overflow-y-auto p-5 sm:p-6 space-y-6 text-slate-800">
          {/* Key Metric Line: Start, Destination, Distance, Duration */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-50 p-4 rounded-xl border border-slate-200 text-xs">
            <div>
              <span className="text-slate-500 block">Origin:</span>
              <strong className="text-slate-900 font-semibold">{bus.startPoint}</strong>
            </div>
            <div>
              <span className="text-slate-500 block">Destination:</span>
              <strong className="text-slate-900 font-semibold">{bus.destination}</strong>
            </div>
            <div>
              <span className="text-slate-500 block">Estimated Distance:</span>
              <strong className="text-slate-900 font-mono font-semibold">{bus.distanceKm} km</strong>
            </div>
            <div>
              <span className="text-slate-500 block">Travel Duration:</span>
              <strong className="text-slate-900 font-semibold">~{bus.estimatedDuration}</strong>
            </div>
          </div>

          {/* Photo Gallery with View Switcher */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                <Bus className="w-4 h-4 text-blue-900" />
                <span>{t.busPhotos}</span>
              </h4>
              <span className="text-[11px] text-slate-500 font-mono">
                Reg: {bus.registrationNumber}
              </span>
            </div>

            {/* View Selector Tabs */}
            <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-lg max-w-fit mb-3">
              {(['front', 'side', 'interior', 'rear'] as const).map((view) => {
                const label =
                  view === 'front'
                    ? t.frontView
                    : view === 'side'
                    ? t.sideView
                    : view === 'interior'
                    ? t.interiorView
                    : t.rearView;
                return (
                  <button
                    key={view}
                    onClick={() => setSelectedPhotoView(view)}
                    className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
                      selectedPhotoView === view
                        ? 'bg-white text-blue-950 font-bold shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {label}
                  </button>
                );
              })}
            </div>

            {/* Selected Photo View with Fallback */}
            <div className="relative rounded-xl overflow-hidden border border-slate-200 bg-slate-950 max-h-72 flex items-center justify-center">
              {currentPhoto ? (
                <img
                  src={currentPhoto.url}
                  alt={`${bus.nameEn} - ${currentPhoto.view}`}
                  referrerPolicy="no-referrer"
                  className="w-full h-72 object-cover object-center"
                />
              ) : (
                <div className="p-8 text-center text-slate-400">
                  <Bus className="w-12 h-12 mx-auto mb-2 text-slate-600" />
                  <p className="text-xs">No photograph submitted for this perspective yet.</p>
                </div>
              )}
              {currentPhoto?.caption && (
                <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent p-3 text-xs text-white">
                  {currentPhoto.caption}
                </div>
              )}
            </div>
          </div>

          {/* Timetables Tabbed Section */}
          <div>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
              <h4 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                <Calendar className="w-4 h-4 text-blue-900" />
                <span>{t.timetable}</span>
              </h4>

              <div className="flex items-center gap-2">
                <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg text-xs">
                  <button
                    onClick={() => setTimetableTab('forward')}
                    className={`px-2.5 py-1 rounded font-medium transition-colors ${
                      timetableTab === 'forward'
                        ? 'bg-white text-blue-950 font-bold shadow-xs'
                        : 'text-slate-600'
                    }`}
                  >
                    {t.forwardDirection} ({bus.timetableForward.length})
                  </button>
                  <button
                    onClick={() => setTimetableTab('return')}
                    className={`px-2.5 py-1 rounded font-medium transition-colors ${
                      timetableTab === 'return'
                        ? 'bg-white text-blue-950 font-bold shadow-xs'
                        : 'text-slate-600'
                    }`}
                  >
                    {t.returnDirection} ({bus.timetableReturn.length})
                  </button>
                </div>

                {onOpenTimetable && (
                  <button
                    onClick={() => {
                      onClose();
                      onOpenTimetable(bus);
                    }}
                    className="text-xs font-semibold text-blue-900 bg-blue-50 hover:bg-blue-100 px-2.5 py-1 rounded-lg border border-blue-200 transition-colors hidden sm:inline-flex items-center gap-1"
                  >
                    <Clock className="w-3 h-3" />
                    <span>Live Calculator →</span>
                  </button>
                )}
              </div>
            </div>

            {/* Tabular Timetable */}
            {activeTimetable.length > 0 ? (
              <div className="border border-slate-200 rounded-xl overflow-hidden">
                <div className="max-h-56 overflow-y-auto">
                  <table className="w-full text-xs text-left">
                    <thead className="bg-slate-100 text-slate-600 font-semibold sticky top-0 border-b border-slate-200">
                      <tr>
                        <th className="py-2.5 px-4">{t.departure}</th>
                        <th className="py-2.5 px-4">{t.arrival}</th>
                        <th className="py-2.5 px-4">From</th>
                        <th className="py-2.5 px-4">Destination</th>
                        <th className="py-2.5 px-4">Operating Days</th>
                        <th className="py-2.5 px-4">Service</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {activeTimetable.map((row) => (
                        <tr key={row.id} className="hover:bg-slate-50 transition-colors">
                          <td className="py-2 px-4 font-mono font-bold text-blue-950 tabular-nums">
                            {format12Hour(row.departureTime)}
                          </td>
                          <td className="py-2 px-4 font-mono text-slate-700 tabular-nums">
                            {format12Hour(row.arrivalTime)}
                            {row.isMidnightCrossing && (
                              <span className="text-[10px] text-amber-700 font-semibold ml-1">
                                (+1 day)
                              </span>
                            )}
                          </td>
                          <td className="py-2 px-4 text-slate-800">{row.origin}</td>
                          <td className="py-2 px-4 text-slate-800">{row.destination}</td>
                          <td className="py-2 px-4 text-slate-600">{row.days.join(', ')}</td>
                          <td className="py-2 px-4">
                            <span className="text-[11px] text-slate-500">
                              {row.isPeakHour ? 'Peak Service' : 'Regular'}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            ) : (
              <div className="p-6 bg-slate-50 rounded-xl border border-slate-200 text-center text-xs text-slate-500">
                <Clock className="w-6 h-6 text-slate-400 mx-auto mb-1" />
                <p className="font-semibold text-slate-700">Timetable not available yet</p>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Scheduled departure times for this direction have not been verified.
                </p>
              </div>
            )}
          </div>

          {/* Intermediate Stops Ordered List */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                <MapPin className="w-4 h-4 text-blue-900" />
                <span>Route Stops in Correct Sequential Order ({bus.orderedStops ? bus.orderedStops.length : bus.intermediateStops.length} Halts)</span>
              </h4>
              <span className="text-xs text-slate-500 font-mono">
                {bus.distanceKm} km total corridor
              </span>
            </div>

            {/* Easy-to-read ordered list of stops */}
            <div className="bg-slate-50 rounded-xl border border-slate-200 overflow-hidden">
              <div className="divide-y divide-slate-200">
                {(bus.orderedStops && bus.orderedStops.length > 0
                  ? bus.orderedStops
                  : bus.intermediateStops.map((name, i): RouteStop => ({
                      order: i + 1,
                      nameEn: name,
                      nameSi: undefined,
                      nameTa: undefined,
                      districtId: undefined,
                      isMajorJunction: i === 0 || i === bus.intermediateStops.length - 1,
                      estimatedMinutesFromStart: undefined,
                    }))
                ).map((stop) => {
                  const isOrigin = stop.order === 1;
                  const isFinal =
                    stop.order ===
                    (bus.orderedStops ? bus.orderedStops.length : bus.intermediateStops.length);

                  return (
                    <div
                      key={stop.order}
                      className={`p-3 sm:px-4 flex items-center justify-between gap-3 text-xs ${
                        isOrigin || isFinal
                          ? 'bg-blue-50/70 font-semibold'
                          : 'hover:bg-white transition-colors'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <span
                          className={`w-6 h-6 rounded-full flex items-center justify-center font-mono font-bold text-[11px] shrink-0 ${
                            isOrigin
                              ? 'bg-emerald-600 text-white'
                              : isFinal
                              ? 'bg-red-600 text-white'
                              : 'bg-slate-200 text-slate-700'
                          }`}
                        >
                          {stop.order < 10 ? `0${stop.order}` : stop.order}
                        </span>

                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-slate-900 font-medium">
                              {stop.nameEn}
                            </span>
                            {stop.nameSi && currentLang !== 'en' && (
                              <span className="text-slate-500 text-[11px]">
                                ({currentLang === 'si' ? stop.nameSi : stop.nameTa || stop.nameSi})
                              </span>
                            )}
                            {stop.isMajorJunction && (
                              <span className="text-[10px] bg-slate-200 text-slate-700 px-1.5 py-0.2 rounded font-medium">
                                Major Hub
                              </span>
                            )}
                          </div>

                          {stop.districtId && (
                            <span className="text-[11px] text-slate-400 capitalize">
                              District: {stop.districtId.replace('_', ' ')}
                            </span>
                          )}
                        </div>
                      </div>

                      <div className="text-right shrink-0">
                        {stop.estimatedMinutesFromStart !== undefined && (
                          <span className="text-slate-500 font-mono text-[11px]">
                            {stop.estimatedMinutesFromStart === 0
                              ? 'Depart 0m'
                              : `+${stop.estimatedMinutesFromStart}m`}
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Associated Districts & Roads Traveled */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-slate-50 p-4 rounded-xl border border-slate-200 text-xs">
            <div>
              <span className="font-semibold text-slate-700 block mb-1">Associated Districts Traversed:</span>
              <div className="flex flex-wrap gap-1">
                {bus.districtsTraversed.map((dist) => (
                  <span
                    key={dist}
                    className="bg-white border border-slate-200 text-slate-700 px-2 py-0.5 rounded capitalize font-medium text-[11px]"
                  >
                    {dist.replace('_', ' ')}
                  </span>
                ))}
              </div>
            </div>

            <div>
              <span className="font-semibold text-slate-700 block mb-1">Roads & Corridors Traveled:</span>
              <div className="text-slate-800 font-medium">
                {bus.roadsTraveled.join(', ')}
              </div>
            </div>
          </div>

          {/* Operational Advisory Warning */}
          <div className="bg-amber-50 border border-amber-200 p-3.5 rounded-xl flex items-start gap-2.5 text-xs text-amber-900">
            <AlertTriangle className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
            <p className="leading-relaxed">
              <strong>Notice:</strong> {t.disclaimerText}
            </p>
          </div>
        </div>

        {/* Modal Footer with Actions and Direct Hotline */}
        <div className="bg-slate-50 px-5 sm:px-6 py-4 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <a
              href={`tel:${bus.verifiedContactNumber}`}
              className="inline-flex items-center gap-1.5 px-3 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-semibold transition-colors"
            >
              <Phone className="w-3.5 h-3.5" />
              <span>Call Depot: {bus.verifiedContactNumber}</span>
            </a>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                onClose();
                onOpenSubmitModal(bus);
              }}
              className="px-3 py-2 border border-slate-300 hover:bg-slate-100 text-slate-700 rounded-lg text-xs font-medium transition-colors"
            >
              Report Correction / Timetable Update
            </button>
            <button
              onClick={onClose}
              className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-semibold transition-colors"
            >
              {t.close}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
