import React from 'react';
import { Bus, Shield, MapPin, Search, Calendar, PlusCircle, Clock } from 'lucide-react';
import { Language } from '../types/transit';
import { TRANSLATIONS } from '../i18n/translations';

interface NavbarProps {
  currentLang: Language;
  onLanguageChange: (lang: Language) => void;
  activeTab: 'search' | 'districts' | 'district_detail' | 'stands' | 'timetables' | 'admin';
  onTabChange: (tab: 'search' | 'districts' | 'stands' | 'timetables' | 'admin') => void;
  onOpenSubmitModal: () => void;
  isAdminAuthenticated: boolean;
  colomboTimeStr: string;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentLang,
  onLanguageChange,
  activeTab,
  onTabChange,
  onOpenSubmitModal,
  isAdminAuthenticated,
  colomboTimeStr,
}) => {
  const t = TRANSLATIONS[currentLang];

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200">
      {/* Sri Lanka Time Bar & Emergency Info */}
      <div className="bg-slate-900 text-slate-300 text-xs px-4 py-1.5 flex flex-wrap items-center justify-between gap-2 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <span className="text-slate-400 font-medium">Sri Lanka Time:</span>
          <span className="font-mono tabular-nums text-white font-semibold">{colomboTimeStr} (Asia/Colombo UTC+5:30)</span>
        </div>
        <div className="flex items-center gap-4 text-slate-400">
          <span>SLTB Inquiries: <strong className="text-white font-mono">1958</strong></span>
          <span aria-hidden="true" className="text-slate-700">·</span>
          <span>NTC Hotline: <strong className="text-white font-mono">1955</strong></span>
          <span aria-hidden="true" className="text-slate-700">·</span>
          <span>Expressway Assist: <strong className="text-white font-mono">1969</strong></span>
        </div>
      </div>

      {/* Main Top Bar adhering strictly to Top Bar Contract */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8 h-16">
          {/* Zone 1: Single clean text element wordmark */}
          <button
            onClick={() => onTabChange('search')}
            className="flex items-center gap-2.5 text-left text-slate-900 focus:outline-none group whitespace-nowrap shrink-0"
          >
            <div className="w-9 h-9 rounded-lg bg-blue-900 flex items-center justify-center text-white shadow-xs">
              <Bus className="w-5 h-5 text-red-400" />
            </div>
            <div className="flex flex-col">
              <span className="text-xl font-bold tracking-tight text-blue-950 group-hover:text-blue-900 transition-colors">
                Bus<span className="text-red-600">Lanka</span>
              </span>
              <span className="text-[10px] text-slate-500 font-medium tracking-wider uppercase -mt-1">
                ශ්‍රී ලංකා බස් සේවය
              </span>
            </div>
          </button>

          {/* Zone 2: 5 concise single-line nav links */}
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
            <button
              onClick={() => onTabChange('search')}
              className={`flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 py-1 ${
                activeTab === 'search'
                  ? 'text-blue-900 font-semibold border-b-2 border-blue-900'
                  : 'hover:text-slate-900'
              }`}
            >
              <Search className="w-4 h-4 text-slate-400" />
              <span>{t.routeNo} & Routes</span>
            </button>

            <button
              onClick={() => onTabChange('timetables')}
              className={`flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 py-1 ${
                activeTab === 'timetables'
                  ? 'text-blue-900 font-semibold border-b-2 border-blue-900'
                  : 'hover:text-slate-900'
              }`}
            >
              <Clock className="w-4 h-4 text-slate-400" />
              <span>{t.timetablesNav}</span>
            </button>

            <button
              onClick={() => onTabChange('districts')}
              className={`flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 py-1 ${
                activeTab === 'districts' || activeTab === 'district_detail'
                  ? 'text-blue-900 font-semibold border-b-2 border-blue-900'
                  : 'hover:text-slate-900'
              }`}
            >
              <MapPin className="w-4 h-4 text-slate-400" />
              <span>{t.allDistricts}</span>
            </button>

            <button
              onClick={() => onTabChange('stands')}
              className={`flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 py-1 ${
                activeTab === 'stands'
                  ? 'text-blue-900 font-semibold border-b-2 border-blue-900'
                  : 'hover:text-slate-900'
              }`}
            >
              <Calendar className="w-4 h-4 text-slate-400" />
              <span>{t.busStands}</span>
            </button>

            <button
              onClick={onOpenSubmitModal}
              className="flex items-center gap-1.5 hover:text-slate-900 transition-colors whitespace-nowrap shrink-0 text-slate-600 py-1"
            >
              <PlusCircle className="w-4 h-4 text-slate-400" />
              <span>{t.submitInfo}</span>
            </button>
          </nav>

          {/* Zone 3: 1 primary action area + Language Selector */}
          <div className="flex items-center gap-3 shrink-0">
            {/* Language Selector */}
            <div className="flex items-center p-0.5 bg-slate-100 rounded-md border border-slate-200 text-xs font-medium">
              <button
                onClick={() => onLanguageChange('en')}
                className={`px-2 py-1 rounded transition-colors whitespace-nowrap ${
                  currentLang === 'en'
                    ? 'bg-white text-blue-950 font-bold shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
                title="English"
              >
                EN
              </button>
              <button
                onClick={() => onLanguageChange('si')}
                className={`px-2 py-1 rounded transition-colors whitespace-nowrap ${
                  currentLang === 'si'
                    ? 'bg-white text-blue-950 font-bold shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
                title="සිංහල"
              >
                සිං
              </button>
              <button
                onClick={() => onLanguageChange('ta')}
                className={`px-2 py-1 rounded transition-colors whitespace-nowrap ${
                  currentLang === 'ta'
                    ? 'bg-white text-blue-950 font-bold shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
                title="தமிழ்"
              >
                த
              </button>
            </div>

            {/* Admin Portal Action */}
            <button
              onClick={() => onTabChange('admin')}
              className={`flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                activeTab === 'admin'
                  ? 'bg-blue-900 text-white'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200 border border-slate-200'
              }`}
            >
              <Shield className={`w-3.5 h-3.5 ${isAdminAuthenticated ? 'text-emerald-500' : 'text-slate-500'}`} />
              <span>{isAdminAuthenticated ? 'Admin Panel' : t.adminPortal}</span>
            </button>
          </div>
        </div>

        {/* Mobile secondary tab bar */}
        <div className="md:hidden flex items-center justify-around py-2 border-t border-slate-100 text-xs overflow-x-auto">
          <button
            onClick={() => onTabChange('search')}
            className={`px-2 py-1 whitespace-nowrap ${activeTab === 'search' ? 'text-blue-900 font-bold' : 'text-slate-600'}`}
          >
            Routes
          </button>
          <button
            onClick={() => onTabChange('timetables')}
            className={`px-2 py-1 whitespace-nowrap ${activeTab === 'timetables' ? 'text-blue-900 font-bold' : 'text-slate-600'}`}
          >
            Timetables
          </button>
          <button
            onClick={() => onTabChange('districts')}
            className={`px-2 py-1 whitespace-nowrap ${activeTab === 'districts' ? 'text-blue-900 font-bold' : 'text-slate-600'}`}
          >
            Districts
          </button>
          <button
            onClick={() => onTabChange('stands')}
            className={`px-2 py-1 whitespace-nowrap ${activeTab === 'stands' ? 'text-blue-900 font-bold' : 'text-slate-600'}`}
          >
            Stands
          </button>
          <button
            onClick={onOpenSubmitModal}
            className="px-2 py-1 whitespace-nowrap text-blue-800 font-medium"
          >
            + Submit
          </button>
        </div>
      </div>
    </header>
  );
};
