import React, { useState } from 'react';
import { MapPin, ArrowRight, Search, Compass } from 'lucide-react';
import { DistrictId, Language, BusRoute } from '../types/transit';
import { SRI_LANKA_PROVINCES, SRI_LANKA_DISTRICTS } from '../data/sriLankaProvinces';
import { TRANSLATIONS } from '../i18n/translations';

interface DistrictBrowserProps {
  currentLang: Language;
  onSelectDistrict: (districtId: DistrictId) => void;
  buses: BusRoute[];
}

export const DistrictBrowser: React.FC<DistrictBrowserProps> = ({
  currentLang,
  onSelectDistrict,
  buses,
}) => {
  const [districtQuery, setDistrictQuery] = useState('');
  const t = TRANSLATIONS[currentLang];

  const filteredDistricts = SRI_LANKA_DISTRICTS.filter((d) => {
    const q = districtQuery.toLowerCase().trim();
    if (!q) return true;
    return (
      d.nameEn.toLowerCase().includes(q) ||
      d.nameSi.toLowerCase().includes(q) ||
      d.nameTa.toLowerCase().includes(q) ||
      d.administrativeCapital.toLowerCase().includes(q)
    );
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      {/* Header & Search */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Compass className="w-5 h-5 text-red-600" />
            <span className="text-xs font-bold text-blue-900 uppercase tracking-wider">
              Island-Wide Transit Map
            </span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            {t.exploreByProvince}
          </h2>
          <p className="text-slate-600 text-xs sm:text-sm mt-1">
            Browse public bus networks across all 25 districts of Sri Lanka, organized under their respective 9 provinces. Click any district to open its dedicated route directory.
          </p>
        </div>

        {/* Quick district filter */}
        <div className="w-full md:w-72">
          <div className="relative flex items-center bg-white border border-slate-300 rounded-lg px-3 py-2 shadow-2xs">
            <Search className="w-4 h-4 text-slate-400 mr-2 shrink-0" />
            <input
              type="text"
              value={districtQuery}
              onChange={(e) => setDistrictQuery(e.target.value)}
              placeholder="Find district (e.g. Galle, යාපනය)..."
              className="w-full text-xs text-slate-900 placeholder-slate-400 focus:outline-none"
            />
          </div>
        </div>
      </div>

      {/* If search query active, show flat list of matching districts */}
      {districtQuery.trim() ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
          {filteredDistricts.map((district) => {
            const distName =
              currentLang === 'si'
                ? district.nameSi
                : currentLang === 'ta'
                ? district.nameTa
                : district.nameEn;

            const districtBusCount = buses.filter((b) =>
              b.districtsTraversed.includes(district.id)
            ).length;

            return (
              <button
                key={district.id}
                onClick={() => onSelectDistrict(district.id)}
                className="bg-white rounded-xl border border-slate-200 p-4 text-left hover:border-blue-300 hover:shadow-xs transition-all group flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-1">
                    <h3 className="text-base font-bold text-slate-900 group-hover:text-blue-900 transition-colors">
                      {distName}
                    </h3>
                    <span className="text-xs font-mono font-semibold bg-blue-50 text-blue-950 px-2 py-0.5 rounded">
                      {districtBusCount} routes
                    </span>
                  </div>
                  <div className="text-xs text-slate-400 mb-2">
                    {district.nameEn} · Capital: {district.administrativeCapital}
                  </div>
                  <p className="text-[11px] text-slate-600 line-clamp-2">
                    {district.descriptionEn}
                  </p>
                </div>

                <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-blue-900 font-semibold">
                  <span>Open District Page</span>
                  <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
                </div>
              </button>
            );
          })}
        </div>
      ) : (
        /* Province grouped view */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {SRI_LANKA_PROVINCES.map((province) => {
            const provName =
              currentLang === 'si'
                ? province.nameSi
                : currentLang === 'ta'
                ? province.nameTa
                : province.nameEn;

            const provinceDistricts = SRI_LANKA_DISTRICTS.filter((d) =>
              province.districts.includes(d.id)
            );

            // Count buses traversing this province
            const provinceBusCount = buses.filter((b) =>
              b.provincesTraversed.includes(province.id)
            ).length;

            return (
              <div
                key={province.id}
                className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs hover:border-blue-300 transition-all flex flex-col justify-between"
              >
                <div className="p-5">
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <div>
                      <h3 className="text-base font-bold text-slate-900">{provName}</h3>
                      <span className="text-xs text-slate-400">
                        {province.nameEn} · {province.districts.length} Districts
                      </span>
                    </div>
                    <span className="text-xs font-mono tabular-nums font-semibold bg-slate-100 text-slate-700 px-2 py-0.5 rounded border border-slate-200">
                      {provinceBusCount} routes
                    </span>
                  </div>

                  {/* District List with Direct Select Buttons */}
                  <div className="space-y-1.5 mt-4">
                    {provinceDistricts.map((district) => {
                      const distName =
                        currentLang === 'si'
                          ? district.nameSi
                          : currentLang === 'ta'
                          ? district.nameTa
                          : district.nameEn;

                      const districtBusCount = buses.filter((b) =>
                        b.districtsTraversed.includes(district.id)
                      ).length;

                      return (
                        <button
                          key={district.id}
                          onClick={() => onSelectDistrict(district.id)}
                          className="w-full flex items-center justify-between px-3 py-2 text-xs rounded-lg hover:bg-blue-50 text-slate-700 hover:text-blue-950 transition-colors text-left group"
                        >
                          <div className="flex items-center gap-2">
                            <MapPin className="w-3.5 h-3.5 text-slate-400 group-hover:text-blue-800 transition-colors" />
                            <span className="font-semibold">{distName}</span>
                            <span className="text-slate-400 text-[11px]">({district.nameEn})</span>
                          </div>
                          <div className="flex items-center gap-1.5 text-slate-400 group-hover:text-blue-800">
                            <span className="font-mono tabular-nums text-[11px]">
                              {districtBusCount}
                            </span>
                            <ArrowRight className="w-3 h-3" />
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="bg-slate-50 px-5 py-2.5 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                  <span>{province.districts.length} administrative districts</span>
                  <button
                    onClick={() => onSelectDistrict(provinceDistricts[0].id)}
                    className="text-blue-900 font-semibold hover:underline"
                  >
                    Explore {provinceDistricts[0].nameEn} →
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
