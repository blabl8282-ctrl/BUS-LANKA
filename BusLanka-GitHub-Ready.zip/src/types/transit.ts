export type ProvinceId =
  | 'western'
  | 'central'
  | 'southern'
  | 'northern'
  | 'eastern'
  | 'north_western'
  | 'north_central'
  | 'uva'
  | 'sabaragamuwa';

export type DistrictId =
  | 'colombo'
  | 'gampaha'
  | 'kalutara'
  | 'kandy'
  | 'matale'
  | 'nuwara_eliya'
  | 'galle'
  | 'matara'
  | 'hambantota'
  | 'jaffna'
  | 'kilinochchi'
  | 'mannar'
  | 'vavuniya'
  | 'mullaitivu'
  | 'batticaloa'
  | 'ampara'
  | 'trincomalee'
  | 'kurunegala'
  | 'puttalam'
  | 'anuradhapura'
  | 'polonnaruwa'
  | 'badulla'
  | 'monaragala'
  | 'ratnapura'
  | 'kegalle';

export interface District {
  id: DistrictId;
  nameEn: string;
  nameSi: string;
  nameTa: string;
  provinceId: ProvinceId;
}

export interface DistrictDetail extends District {
  administrativeCapital: string;
  majorBusStands: string[];
  majorHighways: string[];
  keyTransitHubs: string[];
  descriptionEn: string;
  descriptionSi: string;
  descriptionTa: string;
}

export interface RouteStop {
  order: number;
  nameEn: string;
  nameSi?: string;
  nameTa?: string;
  districtId?: DistrictId;
  isMajorJunction?: boolean;
  estimatedMinutesFromStart?: number;
}

export interface Province {
  id: ProvinceId;
  nameEn: string;
  nameSi: string;
  nameTa: string;
  districts: DistrictId[];
}

export type BusType = 'normal' | 'semi_luxury' | 'luxury_ac' | 'expressway';

export type OperatorType = 'sltb' | 'private';

export interface BusPhoto {
  view: 'front' | 'rear' | 'side' | 'interior';
  url: string;
  caption?: string;
}

export type TimeFormat = '12h' | '24h';

export interface StopSchedule {
  stopName: string;
  arrivalTime: string;   // "HH:MM"
  departureTime: string; // "HH:MM"
  isMajorHalt?: boolean;
}

export interface TimetableEntry {
  id: string;
  departureTime: string; // "HH:MM" 24h format
  arrivalTime: string;   // "HH:MM"
  origin: string;
  destination: string;
  days: string[];        // ['Daily'], ['Mon-Fri'], ['Weekends'], ['Sun-Thu'], etc.
  isPeakHour?: boolean;
  isMidnightCrossing?: boolean;
  stopSchedules?: StopSchedule[];
  busRegNo?: string;
}

export interface BusRoute {
  id: string;
  routeNumber: string;
  nameEn: string;
  nameSi: string;
  nameTa: string;
  startPoint: string;
  destination: string;
  districtsTraversed: DistrictId[];
  provincesTraversed: ProvinceId[];
  intermediateStops: string[];
  orderedStops?: RouteStop[];
  roadsTraveled: string[];
  operator: OperatorType;
  operatorName: string;
  registrationNumber: string;
  busType: BusType;
  verifiedContactNumber: string;
  busStandId?: string;
  busStandName?: string;
  estimatedDuration: string;
  distanceKm: number;
  firstBusForward?: string;
  lastBusForward?: string;
  firstBusReturn?: string;
  lastBusReturn?: string;
  frequencyPeak?: string;
  frequencyOffPeak?: string;
  timetableForward: TimetableEntry[];
  timetableReturn: TimetableEntry[];
  photos: BusPhoto[];
  isVerified: boolean;
  isDemoData: boolean;
  lastUpdated: string;
}

export interface BusStand {
  id: string;
  nameEn: string;
  nameSi: string;
  nameTa: string;
  districtId: DistrictId;
  provinceId: ProvinceId;
  location: string;
  contactNumber: string;
  operatorManagement: string; // e.g., "SLTB Depot", "Municipal Council", "NTC Terminal"
  baysCount: number;
  operatingHours: string;
  facilities: string[];
  keyRoutes: string[];
}

export type SubmissionStatus = 'pending' | 'approved' | 'rejected';

export type SubmissionType = 'new_bus' | 'timetable_update' | 'route_correction' | 'photo_upload';

export interface PassengerSubmission {
  id: string;
  type: SubmissionType;
  routeNumber: string;
  startPoint: string;
  destination: string;
  busType: BusType;
  operator: OperatorType;
  registrationNumber?: string;
  contactNumber?: string;
  suggestedChanges: string;
  photoUrl?: string;
  photoView?: 'front' | 'rear' | 'side' | 'interior';
  submitterName: string;
  submitterContact: string;
  submissionDate: string;
  status: SubmissionStatus;
  adminNotes?: string;
}

export type Language = 'en' | 'si' | 'ta';
