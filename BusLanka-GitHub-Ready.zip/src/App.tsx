import React, { useState, useEffect, useMemo } from 'react';
import { Navbar } from './components/Navbar';
import { DisclaimerBanner } from './components/DisclaimerBanner';
import { SearchHero } from './components/SearchHero';
import { FiltersBar } from './components/FiltersBar';
import { BusCard } from './components/BusCard';
import { BusDetailsModal } from './components/BusDetailsModal';
import { DistrictBrowser } from './components/DistrictBrowser';
import { BusStandDirectory } from './components/BusStandDirectory';
import { PassengerSubmissionModal } from './components/PassengerSubmissionModal';
import { AdminDashboard } from './components/AdminDashboard';
import { Footer } from './components/Footer';

import { DistrictDetailPage } from './components/DistrictDetailPage';
import { TimetableExplorer } from './components/TimetableExplorer';
import {
  BusRoute,
  BusStand,
  PassengerSubmission,
  Language,
  DistrictId,
  BusType,
  OperatorType,
} from './types/transit';
import { storageService } from './services/storageService';
import { getColomboDate } from './utils/colomboTime';
import { TRANSLATIONS } from './i18n/translations';
import { SRI_LANKA_DISTRICTS } from './data/sriLankaProvinces';
import { SearchX, RotateCcw } from 'lucide-react';

export default function App() {
  const [currentLang, setCurrentLang] = useState<Language>(() => {
    return (localStorage.getItem('buslanka_lang') as Language) || 'en';
  });

  const [activeTab, setActiveTab] = useState<'search' | 'districts' | 'district_detail' | 'stands' | 'timetables' | 'admin'>('search');
  const [selectedDistrictDetailId, setSelectedDistrictDetailId] = useState<DistrictId>('colombo');
  const [preselectedRouteId, setPreselectedRouteId] = useState<string | undefined>(undefined);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDistrict, setSelectedDistrict] = useState<DistrictId | 'all'>('all');
  const [selectedBusType, setSelectedBusType] = useState<BusType | 'all'>('all');
  const [selectedOperator, setSelectedOperator] = useState<OperatorType | 'all'>('all');

  // Modals
  const [selectedBus, setSelectedBus] = useState<BusRoute | null>(null);
  const [isSubmitModalOpen, setIsSubmitModalOpen] = useState(false);
  const [prefillBusForSubmit, setPrefillBusForSubmit] = useState<BusRoute | null>(null);

  // App Data
  const [buses, setBuses] = useState<BusRoute[]>(() => storageService.getBuses());
  const [busStands, setBusStands] = useState<BusStand[]>(() => storageService.getBusStands());
  const [submissions, setSubmissions] = useState<PassengerSubmission[]>(() =>
    storageService.getSubmissions()
  );

  // Admin Auth
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState<boolean>(() => {
    return sessionStorage.getItem('buslanka_admin_auth') === 'true';
  });

  // Colombo live clock
  const [colomboTimeStr, setColomboTimeStr] = useState<string>('');

  useEffect(() => {
    const updateTime = () => {
      const d = getColomboDate();
      let hours = d.getHours();
      const minutes = String(d.getMinutes()).padStart(2, '0');
      const seconds = String(d.getSeconds()).padStart(2, '0');
      const ampm = hours >= 12 ? 'PM' : 'AM';
      hours = hours % 12 || 12;
      setColomboTimeStr(`${hours}:${minutes}:${seconds} ${ampm}`);
    };

    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const handleLanguageChange = (lang: Language) => {
    setCurrentLang(lang);
    localStorage.setItem('buslanka_lang', lang);
  };

  const handleAdminLogin = (passkey: string) => {
    if (passkey.trim() === 'admin123' || passkey.trim() === 'sltb2026') {
      setIsAdminAuthenticated(true);
      sessionStorage.setItem('buslanka_admin_auth', 'true');
      return true;
    }
    return false;
  };

  const handleAdminLogout = () => {
    setIsAdminAuthenticated(false);
    sessionStorage.removeItem('buslanka_admin_auth');
    setActiveTab('search');
  };

  const refreshAppData = () => {
    setBuses(storageService.getBuses());
    setBusStands(storageService.getBusStands());
    setSubmissions(storageService.getSubmissions());
  };

  // Filter Buses
  const filteredBuses = useMemo(() => {
    return buses.filter((bus) => {
      // District filter
      if (selectedDistrict !== 'all') {
        if (!bus.districtsTraversed.includes(selectedDistrict)) {
          return false;
        }
      }

      // Bus Type filter
      if (selectedBusType !== 'all') {
        if (bus.busType !== selectedBusType) {
          return false;
        }
      }

      // Operator filter
      if (selectedOperator !== 'all') {
        if (bus.operator !== selectedOperator) {
          return false;
        }
      }

      // Query filter matching all 7 required criteria
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        // 1. Route number (e.g. 01, EX1-01, 138, 87)
        const matchesRouteNo = bus.routeNumber.toLowerCase().includes(q);
        // 2. Starting point & destination
        const matchesStart = bus.startPoint.toLowerCase().includes(q);
        const matchesDest = bus.destination.toLowerCase().includes(q);
        const matchesNameEn = bus.nameEn.toLowerCase().includes(q);
        const matchesNameSi = bus.nameSi.toLowerCase().includes(q);
        const matchesNameTa = bus.nameTa.toLowerCase().includes(q);
        // 3. Intermediate bus stops
        const matchesStops = bus.intermediateStops.some((s) => s.toLowerCase().includes(q));
        const matchesOrderedStops = (bus.orderedStops || []).some(
          (s) =>
            s.nameEn.toLowerCase().includes(q) ||
            (s.nameSi && s.nameSi.toLowerCase().includes(q)) ||
            (s.nameTa && s.nameTa.toLowerCase().includes(q))
        );
        // 4. District
        const matchesDistricts = bus.districtsTraversed.some((d) => {
          if (d.toLowerCase().includes(q)) return true;
          const distMeta = SRI_LANKA_DISTRICTS.find((m) => m.id === d);
          return (
            distMeta &&
            (distMeta.nameEn.toLowerCase().includes(q) ||
              distMeta.nameSi.toLowerCase().includes(q) ||
              distMeta.nameTa.toLowerCase().includes(q))
          );
        });
        // 5. Bus stand
        const matchesStand = (bus.busStandName || '').toLowerCase().includes(q);
        // 6. Registration number
        const matchesReg = bus.registrationNumber.toLowerCase().includes(q);
        // 7. Operator or company
        const matchesOp =
          bus.operatorName.toLowerCase().includes(q) ||
          (bus.operator === 'sltb' &&
            (q.includes('sltb') || q.includes('ctb') || q.includes('ශ්‍රීලංගම') || q.includes('அரசு'))) ||
          (bus.operator === 'private' &&
            (q.includes('private') || q.includes('ntc') || q.includes('පුද්ගලික') || q.includes('தனியார்')));

        const matchesRoads = bus.roadsTraveled.some((r) => r.toLowerCase().includes(q));

        if (
          !matchesRouteNo &&
          !matchesStart &&
          !matchesDest &&
          !matchesNameEn &&
          !matchesNameSi &&
          !matchesNameTa &&
          !matchesStops &&
          !matchesOrderedStops &&
          !matchesDistricts &&
          !matchesStand &&
          !matchesReg &&
          !matchesOp &&
          !matchesRoads
        ) {
          return false;
        }
      }

      return true;
    });
  }, [buses, searchQuery, selectedDistrict, selectedBusType, selectedOperator]);

  const handleResetFilters = () => {
    setSearchQuery('');
    setSelectedDistrict('all');
    setSelectedBusType('all');
    setSelectedOperator('all');
  };

  const handleSelectDistrictFromBrowser = (districtId: DistrictId) => {
    setSelectedDistrictDetailId(districtId);
    setActiveTab('district_detail');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleFilterByStand = (standKeyword: string) => {
    setSearchQuery(standKeyword);
    setActiveTab('search');
    window.scrollTo({ top: 400, behavior: 'smooth' });
  };

  const handleOpenTimetable = (bus: BusRoute) => {
    setPreselectedRouteId(bus.id);
    setActiveTab('timetables');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const t = TRANSLATIONS[currentLang];

  return (
    <div className="min-h-screen flex flex-col bg-slate-100 text-slate-900 font-sans selection:bg-blue-900 selection:text-white">
      {/* 1. Global Navigation Bar */}
      <Navbar
        currentLang={currentLang}
        onLanguageChange={handleLanguageChange}
        activeTab={activeTab}
        onTabChange={(tab) => {
          setActiveTab(tab);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onOpenSubmitModal={() => {
          setPrefillBusForSubmit(null);
          setIsSubmitModalOpen(true);
        }}
        isAdminAuthenticated={isAdminAuthenticated}
        colomboTimeStr={colomboTimeStr}
      />

      {/* 2. Public Transit Advisory Banner */}
      <DisclaimerBanner currentLang={currentLang} />

      {/* Main Content Areas */}
      <main className="flex-1">
        {activeTab === 'search' && (
          <div>
            {/* Search Hero */}
            <SearchHero
              currentLang={currentLang}
              searchQuery={searchQuery}
              onSearchChange={setSearchQuery}
              onPopularSelect={(val) => setSearchQuery(val)}
              colomboTimeStr={colomboTimeStr}
            />

            {/* Filters Bar */}
            <FiltersBar
              currentLang={currentLang}
              selectedDistrict={selectedDistrict}
              onDistrictChange={setSelectedDistrict}
              selectedBusType={selectedBusType}
              onBusTypeChange={setSelectedBusType}
              selectedOperator={selectedOperator}
              onOperatorChange={setSelectedOperator}
              onResetFilters={handleResetFilters}
              resultsCount={filteredBuses.length}
              totalBuses={buses.length}
            />

            {/* Bus Cards Grid or Empty State */}
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
              {filteredBuses.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredBuses.map((bus) => (
                    <BusCard
                      key={bus.id}
                      bus={bus}
                      currentLang={currentLang}
                      onSelectBus={(b) => setSelectedBus(b)}
                      onOpenTimetable={handleOpenTimetable}
                    />
                  ))}
                </div>
              ) : (
                <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center max-w-lg mx-auto shadow-xs my-8">
                  <div className="w-12 h-12 bg-slate-100 rounded-full flex items-center justify-center mx-auto text-slate-400 mb-3">
                    <SearchX className="w-6 h-6" />
                  </div>
                  <h3 className="text-base font-bold text-slate-900 mb-1">
                    {t.searchNoResults}
                  </h3>
                  <p className="text-xs text-slate-500 mb-6 leading-relaxed">
                    {t.searchNoResultsDesc}
                  </p>
                  <button
                    onClick={handleResetFilters}
                    className="inline-flex items-center gap-1.5 px-4 py-2 bg-blue-900 hover:bg-blue-800 text-white rounded-lg text-xs font-semibold transition-colors"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>{t.resetSearch}</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Timetables & Next Bus Calculator Tab */}
        {activeTab === 'timetables' && (
          <TimetableExplorer
            buses={buses}
            currentLang={currentLang}
            onSelectBus={(b) => setSelectedBus(b)}
            onOpenSubmitModal={(bus) => {
              setPrefillBusForSubmit(bus);
              setIsSubmitModalOpen(true);
            }}
            preselectedRouteId={preselectedRouteId}
          />
        )}

        {/* 25 Districts Browser Tab */}
        {activeTab === 'districts' && (
          <DistrictBrowser
            currentLang={currentLang}
            onSelectDistrict={handleSelectDistrictFromBrowser}
            buses={buses}
          />
        )}

        {/* Dedicated District Page */}
        {activeTab === 'district_detail' && (
          <DistrictDetailPage
            districtId={selectedDistrictDetailId}
            currentLang={currentLang}
            buses={buses}
            onBackToDistricts={() => setActiveTab('districts')}
            onSelectBus={(b) => setSelectedBus(b)}
            onOpenTimetable={handleOpenTimetable}
            onSwitchDistrict={(newDistId) => setSelectedDistrictDetailId(newDistId)}
          />
        )}

        {/* Bus Stands Directory Tab */}
        {activeTab === 'stands' && (
          <BusStandDirectory
            busStands={busStands}
            currentLang={currentLang}
            onFilterByStand={handleFilterByStand}
          />
        )}

        {/* Admin Dashboard Tab */}
        {activeTab === 'admin' && (
          <AdminDashboard
            buses={buses}
            busStands={busStands}
            submissions={submissions}
            currentLang={currentLang}
            isAuthenticated={isAdminAuthenticated}
            onLogin={handleAdminLogin}
            onLogout={handleAdminLogout}
            onRefreshData={refreshAppData}
            onEditBus={(bus) => {
              setSelectedBus(bus);
            }}
          />
        )}
      </main>

      {/* Bus Details Modal */}
      <BusDetailsModal
        bus={selectedBus}
        currentLang={currentLang}
        onClose={() => setSelectedBus(null)}
        onOpenSubmitModal={(bus) => {
          setPrefillBusForSubmit(bus);
          setIsSubmitModalOpen(true);
        }}
        onOpenTimetable={handleOpenTimetable}
        colomboTimeStr={colomboTimeStr}
      />

      {/* Passenger Submission Modal */}
      <PassengerSubmissionModal
        isOpen={isSubmitModalOpen}
        onClose={() => {
          setIsSubmitModalOpen(false);
          setPrefillBusForSubmit(null);
        }}
        prefillBus={prefillBusForSubmit}
        currentLang={currentLang}
        onSubmissionSuccess={() => {
          refreshAppData();
        }}
      />

      {/* Quiet Footer */}
      <Footer currentLang={currentLang} onSelectTab={setActiveTab} />
    </div>
  );
}
