import { Language } from '../types/transit';

export interface TranslationDictionary {
  appName: string;
  tagline: string;
  subtitle: string;
  searchPlaceholder: string;
  allDistricts: string;
  allProvinces: string;
  filterByDistrict: string;
  filterByBusType: string;
  filterByOperator: string;
  allOperators: string;
  allTypes: string;
  popularSearches: string;
  clearFilters: string;
  busesFound: string;
  routeNo: string;
  operator: string;
  sltb: string;
  privateOp: string;
  busType: string;
  normal: string;
  semiLuxury: string;
  luxuryAc: string;
  expressway: string;
  departure: string;
  arrival: string;
  nextBus: string;
  timeRemaining: string;
  colomboTime: string;
  viewDetails: string;
  busStands: string;
  busStandsDirectory: string;
  passengerSubmissions: string;
  submitInfo: string;
  adminPortal: string;
  demoDataNotice: string;
  disclaimerTitle: string;
  disclaimerText: string;
  noBookingDisclaimer: string;
  intermediateStops: string;
  roadsTraveled: string;
  distance: string;
  duration: string;
  registrationNo: string;
  verifiedHotline: string;
  busPhotos: string;
  frontView: string;
  rearView: string;
  sideView: string;
  interiorView: string;
  timetable: string;
  forwardDirection: string;
  returnDirection: string;
  searchNoResults: string;
  searchNoResultsDesc: string;
  resetSearch: string;
  exploreByProvince: string;
  submitBusTitle: string;
  submitBusSubtitle: string;
  typeOfSubmission: string;
  submitterName: string;
  submitterContact: string;
  suggestedChanges: string;
  sendSubmission: string;
  submissionSuccess: string;
  close: string;
  verifiedStatus: string;
  statusPending: string;
  statusApproved: string;
  statusRejected: string;
  timetablesNav: string;
  nextBusCalculator: string;
  timetableNotAvailable: string;
  timetableNotAvailableDesc: string;
  manageTimetables: string;
}

export const TRANSLATIONS: Record<Language, TranslationDictionary> = {
  en: {
    appName: 'BusLanka',
    tagline: 'Find Your Bus in Sri Lanka',
    subtitle: 'Official public bus routes, timetables, and bus stand directory across all 25 districts.',
    searchPlaceholder: 'Search route (01, 138), city (Kandy), stand (Pettah), or reg no...',
    allDistricts: 'All Districts (25)',
    allProvinces: 'All Provinces (9)',
    filterByDistrict: 'Filter by District',
    filterByBusType: 'Bus Type',
    filterByOperator: 'Operator',
    allOperators: 'All Operators',
    allTypes: 'All Types',
    popularSearches: 'Popular Searches',
    clearFilters: 'Clear Filters',
    busesFound: 'buses found',
    routeNo: 'Route',
    operator: 'Operator',
    sltb: 'SLTB (Government)',
    privateOp: 'Private (NTC)',
    busType: 'Service Type',
    normal: 'Normal Service',
    semiLuxury: 'Semi-Luxury',
    luxuryAc: 'Luxury / AC',
    expressway: 'Expressway Service',
    departure: 'Departure',
    arrival: 'Arrival',
    nextBus: 'Next Scheduled Departure',
    timeRemaining: 'Remaining',
    colomboTime: 'Sri Lanka Time (UTC+5:30)',
    viewDetails: 'View Timetable & Details',
    busStands: 'Bus Stands',
    busStandsDirectory: 'Sri Lanka Bus Stand Directory',
    passengerSubmissions: 'Passenger Updates',
    submitInfo: 'Submit Info / Update',
    adminPortal: 'Admin Portal',
    demoDataNotice: 'DEMO TRANSIT DATA',
    disclaimerTitle: 'Public Transit Operational Notice',
    disclaimerText: 'Scheduled times may fluctuate due to traffic density, monsoonal weather, road maintenance, and operating delays. BusLanka provides scheduled passenger information only and does not track live bus GPS locations.',
    noBookingDisclaimer: 'BusLanka is strictly an information & timetable directory. Ticket purchases, seat reservations, and conductor bookings are not conducted on this platform.',
    intermediateStops: 'Intermediate Stops',
    roadsTraveled: 'Roads Traveled',
    distance: 'Distance',
    duration: 'Est. Duration',
    registrationNo: 'Bus Reg. No',
    verifiedHotline: 'Verified Depot / Hotline',
    busPhotos: 'Bus Photos',
    frontView: 'Front View',
    rearView: 'Rear View',
    sideView: 'Side View',
    interiorView: 'Interior Cabin',
    timetable: 'Scheduled Timetable',
    forwardDirection: 'Outbound Timetable',
    returnDirection: 'Return Timetable',
    searchNoResults: 'No buses match your search',
    searchNoResultsDesc: 'Try searching by a broader city name, route number (e.g. 01, 100), or clear active filters.',
    resetSearch: 'Reset Search',
    exploreByProvince: 'Explore All 25 Districts by Province',
    submitBusTitle: 'Passenger Contribution & Correction Form',
    submitBusSubtitle: 'Help fellow Sri Lankan commuters by reporting revised departure times, new routes, bus photos, or depot contact changes.',
    typeOfSubmission: 'Submission Type',
    submitterName: 'Your Name',
    submitterContact: 'Phone / Email',
    suggestedChanges: 'Details of update, route stops, or timetable change',
    sendSubmission: 'Submit for Admin Verification',
    submissionSuccess: 'Thank you! Your contribution has been submitted for verification by the BusLanka administration team.',
    close: 'Close',
    verifiedStatus: 'Verified Info',
    statusPending: 'Pending Review',
    statusApproved: 'Approved',
    statusRejected: 'Rejected',
    timetablesNav: 'Timetables & Next Bus',
    nextBusCalculator: 'Next Scheduled Bus Calculator',
    timetableNotAvailable: 'Timetable Not Available Yet',
    timetableNotAvailableDesc: 'Official scheduled departure times for this route have not yet been registered. You can submit timetable updates via the passenger form.',
    manageTimetables: 'Timetable Management',
  },
  si: {
    appName: 'BusLanka',
    tagline: 'ශ්‍රී ලංකාවේ ඔබේ බස් රථය සොයාගන්න',
    subtitle: 'දිස්ත්‍රික්ක 25 පුරා නිල බස් මාර්ග, කාලසටහන් සහ බස් නැවතුම්පොළ තොරතුරු පද්ධතිය.',
    searchPlaceholder: 'මාර්ග අංකය (01, 138), නගරය (මහනුවර), නැවතුම (පිටකොටුව)...',
    allDistricts: 'සියලු දිස්ත්‍රික්ක (25)',
    allProvinces: 'සියලු පළාත් (9)',
    filterByDistrict: 'දිස්ත්‍රික්කය අනුව',
    filterByBusType: 'සේවා වර්ගය',
    filterByOperator: 'ක්‍රියාකරු',
    allOperators: 'සියලු ක්‍රියාකරුවන්',
    allTypes: 'සියලු සේවා',
    popularSearches: 'ජනප්‍රිය සෙවුම්',
    clearFilters: 'පෙරහන් ඉවත් කරන්න',
    busesFound: 'බස් රථ හමුවිය',
    routeNo: 'මාර්ග අංකය',
    operator: 'ක්‍රියාකරු',
    sltb: 'ශ්‍රීලංගම (රජයේ)',
    privateOp: 'පුද්ගලික (NTC)',
    busType: 'බස් රථ වර්ගය',
    normal: 'සාමාන්‍ය සේවය',
    semiLuxury: 'අර්ධ සුඛෝපභෝගී',
    luxuryAc: 'සුඛෝපභෝගී වායුසමනය කළ',
    expressway: 'අධිවේගී මාර්ග සේවය',
    departure: 'පිටත්වීම',
    arrival: 'ළඟාවීම',
    nextBus: 'මීළඟ පිටත්වීම',
    timeRemaining: 'ඉතිරි කාලය',
    colomboTime: 'ශ්‍රී ලංකා වේලාව (UTC+5:30)',
    viewDetails: 'කාලසටහන සහ විස්තර',
    busStands: 'බස් නැවතුම්පොළ',
    busStandsDirectory: 'ශ්‍රී ලංකා බස් නැවතුම්පොළ නාමාවලිය',
    passengerSubmissions: 'මගී තොරතුරු',
    submitInfo: 'තොරතුරු යොමු කරන්න',
    adminPortal: 'පරිපාලක පද්ධතිය',
    demoDataNotice: 'ආදර්ශන තොරතුරු (DEMO)',
    disclaimerTitle: 'පොදු ප්‍රවාහන නිවේදනය',
    disclaimerText: 'මාර්ග තදබදය, කාලගුණය සහ මෙහෙයුම් ප්‍රමාදයන් හේතුවෙන් පිටත්වීමේ වේලාවන් වෙනස් විය හැක. BusLanka සජීවී ජීපීඑස් පිහිටීම් ලබා නොදේ.',
    noBookingDisclaimer: 'BusLanka යනු තොරතුරු නාමාවලියක් පමණි. ආසන වෙන්කිරීම් හෝ ටිකට්පත් මිලදී ගැනීම් මෙහි සිදු නොකෙරේ.',
    intermediateStops: 'අතරමග නැවතුම්',
    roadsTraveled: 'ධාවනය වන මාර්ග',
    distance: 'දුර ප්‍රමාණය',
    duration: 'ඇස්තමේන්තුගත කාලය',
    registrationNo: 'ලියාපදිංචි අංකය',
    verifiedHotline: 'තහවුරු කළ දුරකථන අංකය',
    busPhotos: 'බස් රථ ඡායාරූප',
    frontView: 'ඉදිරිපස පෙනුම',
    rearView: 'පසුපස පෙනුම',
    sideView: 'පැති පෙනුම',
    interiorView: 'ඇතුළත ආසන',
    timetable: 'ධාවන කාලසටහන',
    forwardDirection: 'ගමනාන්තය දක්වා කාලසටහන',
    returnDirection: 'ආපසු ගමන කාලසටහන',
    searchNoResults: 'බස් රථ හමු නොවීය',
    searchNoResultsDesc: 'වෙනත් නගරයක් හෝ මාර්ග අංකයක් මඟින් නැවත සොයන්න.',
    resetSearch: 'සෙවුම යළි පිහිටුවන්න',
    exploreByProvince: 'පළාත් අනුව දිස්ත්‍රික්ක 25 ගවේෂණය',
    submitBusTitle: 'මගී තොරතුරු සහ සංශෝධන පෝරමය',
    submitBusSubtitle: 'නව බස් රථ තොරතුරු, වේලාවන් හෝ ඡායාරූප ඉදිරිපත් කර අනෙක් මගීන්ට උපකාර වන්න.',
    typeOfSubmission: 'ඉදිරිපත් කිරීමේ වර්ගය',
    submitterName: 'ඔබේ නම',
    submitterContact: 'දුරකථනය / විද්‍යුත් තැපෑල',
    suggestedChanges: 'වෙනස්කම් හෝ නව තොරතුරු විස්තරය',
    sendSubmission: 'පරිපාලක අනුමැතියට යොමු කරන්න',
    submissionSuccess: 'ස්තූතියි! ඔබේ තොරතුරු පරිපාලක පරීක්ෂාව සඳහා යොමු කෙරිණි.',
    close: 'වසන්න',
    verifiedStatus: 'තහවුරු කළ තොරතුරු',
    statusPending: 'පොරොත්තුවේ',
    statusApproved: 'අනුමතයි',
    statusRejected: 'ප්‍රතික්ෂේපිතයි',
    timetablesNav: 'කාලසටහන් සහ මීළඟ බස් රථය',
    nextBusCalculator: 'මීළඟ ධාවන ගණකය',
    timetableNotAvailable: 'කාලසටහන තවමත් නොමැත',
    timetableNotAvailableDesc: 'මෙම මාර්ගය සඳහා නිල කාලසටහන් තවමත් ලියාපදිංචි කර නැත. මගී පෝරමය මඟින් ඔබට තොරතුරු ඉදිරිපත් කළ හැක.',
    manageTimetables: 'කාලසටහන් කළමනාකරණය',
  },
  ta: {
    appName: 'BusLanka',
    tagline: 'இலங்கையில் உங்கள் பேருந்தை கண்டறியுங்கள்',
    subtitle: '25 மாவட்டங்களிலுமான பொதுப் பேருந்து வழித்தடங்கள், நேர அட்டவணைகள் மற்றும் பஸ் நிலைய விபரங்கள்.',
    searchPlaceholder: 'வழித்தட எண் (01, 138), நகரம் (கண்டி), தரிப்பிடம் (புறக்கோட்டை)...',
    allDistricts: 'அனைத்து மாவட்டங்கள் (25)',
    allProvinces: 'அனைத்து மாகாணங்கள் (9)',
    filterByDistrict: 'மாவட்டம் வாரியாக',
    filterByBusType: 'சேவை வகை',
    filterByOperator: 'இயக்குனர்',
    allOperators: 'அனைத்து இயக்குனர்கள்',
    allTypes: 'அனைத்து வகைகள்',
    popularSearches: 'பிரபலமான தேடல்கள்',
    clearFilters: 'வடிகட்டிகளை அகற்று',
    busesFound: 'பேருந்துகள் கிடைத்தன',
    routeNo: 'வழித்தடம்',
    operator: 'இயக்குனர்',
    sltb: 'SLTB (அரசு)',
    privateOp: 'தனியார் (NTC)',
    busType: 'பேருந்து வகை',
    normal: 'சாதாரண சேவை',
    semiLuxury: 'அரை சொகுசு',
    luxuryAc: 'சொகுசு / ஏசி',
    expressway: 'அதிவேக நெடுஞ்சாலை சேவை',
    departure: 'புறப்பாடு',
    arrival: 'வருகை',
    nextBus: 'அடுத்த திட்டமிடப்பட்ட புறப்பாடு',
    timeRemaining: 'மீதமுள்ள நேரம்',
    colomboTime: 'இலங்கை நேரம் (UTC+5:30)',
    viewDetails: 'நேர அட்டவணை மற்றும் விபரங்கள்',
    busStands: 'பஸ் நிலையங்கள்',
    busStandsDirectory: 'இலங்கை பஸ் நிலைய விபரக்கொத்து',
    passengerSubmissions: 'பயணிகள் தகவல்',
    submitInfo: 'தகவல் சமர்ப்பிக்க',
    adminPortal: 'நிர்வாக தளம்',
    demoDataNotice: 'மாதிரி தகவல் (DEMO)',
    disclaimerTitle: 'பொதுப் போக்குவரத்து அறிவிப்பு',
    disclaimerText: 'போக்குவரத்து நெரிசல், வானிலை மற்றும் இயக்க தாமதங்கள் காரணமாக திட்டமிடப்பட்ட நேரங்கள் மாறக்கூடும். BusLanka நேரலை ஜிபிஎஸ் வழங்குவதில்லை.',
    noBookingDisclaimer: 'BusLanka ஒரு தகவல் வழிகாட்டி மட்டுமே. ஆசன முன்பதிவு அல்லது டிக்கெட் விற்பனை இங்கு செய்யப்படுவதில்லை.',
    intermediateStops: 'இடைப்பட்ட நிறுத்தங்கள்',
    roadsTraveled: 'பயணிக்கும் பாதைகள்',
    distance: 'தூரம்',
    duration: 'மதிப்பிடப்பட்ட நேரம்',
    registrationNo: 'பதிவு இலக்கம்',
    verifiedHotline: 'சரிபார்க்கப்பட்ட தொடர்பு எண்',
    busPhotos: 'பேருந்து புகைப்படங்கள்',
    frontView: 'முன்புற தோற்றம்',
    rearView: 'பின்புற தோற்றம்',
    sideView: 'பக்க தோற்றம்',
    interiorView: 'உட்புற இருக்கைகள்',
    timetable: 'திட்டமிடப்பட்ட நேர அட்டவணை',
    forwardDirection: 'செல்லும் நேர அட்டவணை',
    returnDirection: 'திரும்பும் நேர அட்டவணை',
    searchNoResults: 'பேருந்துகள் எதுவும் கிடைக்கவில்லை',
    searchNoResultsDesc: 'மற்றொரு நகரம் அல்லது வழித்தட எண்ணை உள்ளிட்டு முயற்சிக்கவும்.',
    resetSearch: 'மீட்டமைக்கவும்',
    exploreByProvince: 'மாகாணம் வாரியாக 25 மாவட்டங்கள்',
    submitBusTitle: 'பயணிகள் பங்களிப்பு மற்றும் திருத்தப் படிவம்',
    submitBusSubtitle: 'புதிய பேருந்து விபரங்கள் அல்லது நேர மாற்றங்களை சமர்ப்பித்து சக பயணிகளுக்கு உதவுங்கள்.',
    typeOfSubmission: 'சமர்ப்பிப்பு வகை',
    submitterName: 'உங்கள் பெயர்',
    submitterContact: 'தொலைபேசி / மின்னஞ்சல்',
    suggestedChanges: 'மாற்றங்கள் அல்லது விபரங்கள்',
    sendSubmission: 'சரிபார்ப்புக்கு சமர்ப்பிக்கவும்',
    submissionSuccess: 'நன்றி! உங்கள் தகவல் நிர்வாக ஆய்வுக்கு அனுப்பப்பட்டுள்ளது.',
    close: 'மூடுக',
    verifiedStatus: 'சரிபார்க்கப்பட்ட விபரம்',
    statusPending: 'நிலுவையில்',
    statusApproved: 'ஏற்கப்பட்டது',
    statusRejected: 'நிராகரிக்கப்பட்டது',
    timetablesNav: 'நேர அட்டவணைகளும் அடுத்த பேருந்தும்',
    nextBusCalculator: 'அடுத்த பேருந்து கால்குலேட்டர்',
    timetableNotAvailable: 'நேர அட்டவணை இன்னும் கிடைக்கவில்லை',
    timetableNotAvailableDesc: 'இந்த வழித்தடத்திற்கான அதிகாரப்பூர்வ நேரங்கள் இன்னும் பதிவு செய்யப்படவில்லை. பயணிகள் படிவம் மூலம் சமர்ப்பிக்கலாம்.',
    manageTimetables: 'நேர அட்டவணை மேலாண்மை',
  },
};
