import { BusRoute, BusStand, PassengerSubmission } from '../types/transit';
import { INITIAL_BUSES } from '../data/initialBuses';
import { INITIAL_BUS_STANDS } from '../data/initialBusStands';

const BUSES_STORAGE_KEY = 'buslanka_buses_v1';
const BUS_STANDS_STORAGE_KEY = 'buslanka_bus_stands_v1';
const SUBMISSIONS_STORAGE_KEY = 'buslanka_submissions_v1';

const INITIAL_SUBMISSIONS: PassengerSubmission[] = [
  {
    id: 'sub-101',
    type: 'timetable_update',
    routeNumber: '01',
    startPoint: 'Colombo Fort',
    destination: 'Kandy Goodshed',
    busType: 'normal',
    operator: 'sltb',
    registrationNumber: 'NB-4521',
    contactNumber: '+94 81 222 2222',
    suggestedChanges: 'Depot added a new night departure at 22:30 from Colombo Fort on Friday evenings to assist university students returning home.',
    submitterName: 'Kasun Bandara',
    submitterContact: 'kasun.b@example.lk',
    submissionDate: '2026-10-13 14:20',
    status: 'pending',
  },
  {
    id: 'sub-102',
    type: 'photo_upload',
    routeNumber: 'EX1-01',
    startPoint: 'Makumbura MMC',
    destination: 'Galle Central',
    busType: 'expressway',
    operator: 'sltb',
    registrationNumber: 'WP ND-8920',
    suggestedChanges: 'Submitted new high-resolution photo of the newly allocated Volvo/Yutong AC coach operating the Southern Expressway morning schedule.',
    photoUrl: './images/expressway_luxury_bus_1791961707591.jpg',
    photoView: 'side',
    submitterName: 'Dilshan Silva',
    submitterContact: '+94 77 123 4567',
    submissionDate: '2026-10-13 09:15',
    status: 'pending',
  },
  {
    id: 'sub-103',
    type: 'route_correction',
    routeNumber: '138',
    startPoint: 'Pettah',
    destination: 'Homagama',
    busType: 'normal',
    operator: 'private',
    suggestedChanges: 'Please update that Route 138 now also has a dedicated halt directly outside the newly constructed Kottawa hospital entrance.',
    submitterName: 'Nirosha Perera',
    submitterContact: 'nirosha.p@mail.lk',
    submissionDate: '2026-10-12 18:40',
    status: 'approved',
    adminNotes: 'Verified with Western Province Passenger Transport Authority route bulletin.',
  },
];

export const storageService = {
  getBuses(): BusRoute[] {
    try {
      const data = localStorage.getItem(BUSES_STORAGE_KEY);
      if (data) {
        return JSON.parse(data);
      }
    } catch {
      // fallback to initial
    }
    return INITIAL_BUSES;
  },

  saveBuses(buses: BusRoute[]): void {
    try {
      localStorage.setItem(BUSES_STORAGE_KEY, JSON.stringify(buses));
    } catch (e) {
      console.warn('Could not save to localStorage', e);
    }
  },

  addBus(bus: BusRoute): BusRoute[] {
    const current = this.getBuses();
    const updated = [bus, ...current];
    this.saveBuses(updated);
    return updated;
  },

  updateBus(bus: BusRoute): BusRoute[] {
    const current = this.getBuses();
    const updated = current.map((b) => (b.id === bus.id ? bus : b));
    this.saveBuses(updated);
    return updated;
  },

  deleteBus(id: string): BusRoute[] {
    const current = this.getBuses();
    const updated = current.filter((b) => b.id !== id);
    this.saveBuses(updated);
    return updated;
  },

  addTimetableEntry(
    routeId: string,
    direction: 'forward' | 'return',
    entry: Omit<import('../types/transit').TimetableEntry, 'id'>
  ): BusRoute[] {
    const current = this.getBuses();
    const newId = `t-${direction}-${Date.now()}`;
    const newEntry: import('../types/transit').TimetableEntry = {
      ...entry,
      id: newId,
    };

    const updated = current.map((bus) => {
      if (bus.id === routeId) {
        if (direction === 'forward') {
          const list = [...bus.timetableForward, newEntry].sort((a, b) =>
            a.departureTime.localeCompare(b.departureTime)
          );
          return {
            ...bus,
            timetableForward: list,
            firstBusForward: list[0]?.departureTime || bus.firstBusForward,
            lastBusForward: list[list.length - 1]?.departureTime || bus.lastBusForward,
          };
        } else {
          const list = [...bus.timetableReturn, newEntry].sort((a, b) =>
            a.departureTime.localeCompare(b.departureTime)
          );
          return {
            ...bus,
            timetableReturn: list,
            firstBusReturn: list[0]?.departureTime || bus.firstBusReturn,
            lastBusReturn: list[list.length - 1]?.departureTime || bus.lastBusReturn,
          };
        }
      }
      return bus;
    });

    this.saveBuses(updated);
    return updated;
  },

  updateTimetableEntry(
    routeId: string,
    direction: 'forward' | 'return',
    updatedEntry: import('../types/transit').TimetableEntry
  ): BusRoute[] {
    const current = this.getBuses();
    const updated = current.map((bus) => {
      if (bus.id === routeId) {
        const key = direction === 'forward' ? 'timetableForward' : 'timetableReturn';
        const list = bus[key]
          .map((e) => (e.id === updatedEntry.id ? updatedEntry : e))
          .sort((a, b) => a.departureTime.localeCompare(b.departureTime));

        if (direction === 'forward') {
          return {
            ...bus,
            timetableForward: list,
            firstBusForward: list[0]?.departureTime,
            lastBusForward: list[list.length - 1]?.departureTime,
          };
        } else {
          return {
            ...bus,
            timetableReturn: list,
            firstBusReturn: list[0]?.departureTime,
            lastBusReturn: list[list.length - 1]?.departureTime,
          };
        }
      }
      return bus;
    });

    this.saveBuses(updated);
    return updated;
  },

  deleteTimetableEntry(
    routeId: string,
    direction: 'forward' | 'return',
    entryId: string
  ): BusRoute[] {
    const current = this.getBuses();
    const updated = current.map((bus) => {
      if (bus.id === routeId) {
        if (direction === 'forward') {
          const list = bus.timetableForward.filter((e) => e.id !== entryId);
          return {
            ...bus,
            timetableForward: list,
            firstBusForward: list[0]?.departureTime,
            lastBusForward: list[list.length - 1]?.departureTime,
          };
        } else {
          const list = bus.timetableReturn.filter((e) => e.id !== entryId);
          return {
            ...bus,
            timetableReturn: list,
            firstBusReturn: list[0]?.departureTime,
            lastBusReturn: list[list.length - 1]?.departureTime,
          };
        }
      }
      return bus;
    });

    this.saveBuses(updated);
    return updated;
  },

  getBusStands(): BusStand[] {
    try {
      const data = localStorage.getItem(BUS_STANDS_STORAGE_KEY);
      if (data) {
        return JSON.parse(data);
      }
    } catch {
      // fallback
    }
    return INITIAL_BUS_STANDS;
  },

  saveBusStands(stands: BusStand[]): void {
    try {
      localStorage.setItem(BUS_STANDS_STORAGE_KEY, JSON.stringify(stands));
    } catch (e) {
      console.warn('Could not save bus stands', e);
    }
  },

  getSubmissions(): PassengerSubmission[] {
    try {
      const data = localStorage.getItem(SUBMISSIONS_STORAGE_KEY);
      if (data) {
        return JSON.parse(data);
      }
    } catch {
      // fallback
    }
    return INITIAL_SUBMISSIONS;
  },

  saveSubmissions(submissions: PassengerSubmission[]): void {
    try {
      localStorage.setItem(SUBMISSIONS_STORAGE_KEY, JSON.stringify(submissions));
    } catch (e) {
      console.warn('Could not save submissions', e);
    }
  },

  addSubmission(sub: Omit<PassengerSubmission, 'id' | 'submissionDate' | 'status'>): PassengerSubmission {
    const current = this.getSubmissions();
    const now = new Date();
    const newEntry: PassengerSubmission = {
      ...sub,
      id: `sub-${Date.now()}`,
      submissionDate: `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`,
      status: 'pending',
    };
    const updated = [newEntry, ...current];
    this.saveSubmissions(updated);
    return newEntry;
  },

  updateSubmissionStatus(id: string, status: 'approved' | 'rejected', adminNotes?: string): PassengerSubmission[] {
    const current = this.getSubmissions();
    const updated = current.map((s) => {
      if (s.id === id) {
        return {
          ...s,
          status,
          adminNotes: adminNotes || s.adminNotes,
        };
      }
      return s;
    });
    this.saveSubmissions(updated);
    return updated;
  },

  resetAllToDefaults(): void {
    localStorage.removeItem(BUSES_STORAGE_KEY);
    localStorage.removeItem(BUS_STANDS_STORAGE_KEY);
    localStorage.removeItem(SUBMISSIONS_STORAGE_KEY);
  },
};
